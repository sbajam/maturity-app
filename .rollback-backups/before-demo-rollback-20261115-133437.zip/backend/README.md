# Backend MVP

Implementation documentation:

- [Implementation status](docs/implementation/IMPLEMENTATION_STATUS.md)
- [API traceability](docs/implementation/API_TRACEABILITY.md)
- [Technical decisions](docs/implementation/DECISIONS.md)
- [Database integration](docs/implementation/DATABASE_INTEGRATION.md)
- [API integration tests](docs/implementation/API_INTEGRATION_TEST_REPORT.md)

The API is private and unauthenticated. Configure a private reverse proxy and network access before deployment. Copy `.env.example` to an untracked `.env` and provide actual settings outside version control. The app listens on loopback only.

`npm run typecheck` emits no files; `npm run build` compiles into `dist/`, and `npm test` runs database-independent unit tests. Set `DATABASE_URL` for Sequelize CLI and check the target and migration state before migration. The existing enterprise integration test requires `NODE_ENV=test` and a dedicated database ending in `_test`; see the integration report before running the suite.

The demo seed is `scripts/seed-demo.ts`; it requires `APP_MODE=demo`, a database ending in `_demo`, and `REAL_DATABASE_URL` and `REAL_UPLOAD_ROOT` identifying the separate real environment. Both upload roots must already exist so their real paths can be checked. Run it only against the verified isolated demo database. Files and database backups must be coordinated. Run `scripts/reconcile-files.ts --writers-stopped` only after stopping all writers, and review its output. It uses a 24-hour grace period for orphan objects and staging files.

The frontend remains on mock data. AI, scoring, external connectors and real UI integration are outside the current phase.
