# API integration test report

## Development database

The runtime workflow in `tests/integration/runtime-dev.test.ts` targets only `127.0.0.1:5432/maturity_app_dev` as `maturity_user` and checks `current_database()` before creating uniquely named test records. It runs the real Express router, controllers, services, Sequelize models and PostgreSQL through local HTTP. It passed against PostgreSQL 18.7.

All 17 operations returned the expected success status: enterprise list/create/get/delete; source list/create/patch/delete; assessment list/create/get/delete; dashboard; document list/upload/download/delete. The workflow also checked persisted data, draft status, dashboard counts across two organizations, pagination, cross-enterprise 404, dependent deletion 409, and invalid inputs. It uploaded and downloaded TXT, PDF and DOCX files, verified SHA-256 and bytes, rejected an invalid PDF, empty upload and oversized upload, and completed concurrent uploads. Test records were deleted via the API. The application was also started from the compiled output on an ephemeral loopback port and returned dashboard HTTP 200.

An isolated temporary storage root was used. An invalid storage path returned a sanitized 503; `ENOTDIR` was added to the I/O error mapping. A document was placed in quarantine and restored by reconciliation twice using real metadata; a simulated model-destroy failure caused a real database rollback and restored the file. Invalid FK, blank-name and assessment-status inserts were rejected by PostgreSQL within a transaction that was rolled back. A connection to a closed local port returned a sanitized 503.

One test iteration failed because the test client did not collect binary response bytes correctly; its response parser was fixed, and subsequent runs passed. This was a test-harness error. Typecheck and build passed, as did 41 unit tests and the two targeted integration test files. The older `tests/integration/enterprise.test.ts` was not run: its guard requires a database ending in `_test`, and no such database was authorized or created.

## Remaining validation

- A real process crash at each file/DB boundary and an uncertain PostgreSQL commit outcome have not been simulated. Mock tests cover selected outcomes but do not prove crash atomicity.
- Broader concurrent mutation races, representative production-sized datasets, deployment-network isolation, and all database/OS failure modes remain unverified.
- Integration suite coverage is not comprehensive; the existing `_test` suite remains unrun until an isolated test database is provided or its strategy is explicitly revised.
- DOCX checking is conservative ZIP and required-entry checking, not full OOXML validation. The PDF fixture is a minimal document.
