# API traceability

All paths are under `/api/v1`. Each row points to files in `src/{routes,controllers,services}` with the indicated base name. Migration and model mappings follow the named tables. Frontend integration progress and remaining verification are recorded in [FRONTEND_INTEGRATION.md](FRONTEND_INTEGRATION.md).

| Operation | Route / controller / service | Models and migrations | Relevant tests | Planned frontend consumer |
|---|---|---|---|---|
| GET, POST `/enterprises` | enterprise | enterprise / 001 | enterprise-data-source | enterprise list and modal |
| GET, DELETE `/enterprises/:E` | enterprise | enterprise, data-source, assessment / 001, 002, 004 | ownership | enterprise context |
| GET, POST `/enterprises/:E/data-sources` | data-source | enterprise, data-source / 001, 002 | enterprise-data-source | data-sources page |
| PATCH, DELETE `/enterprises/:E/data-sources/:S` | data-source | data-source, source-document / 002, 003 | ownership | data-sources page |
| GET, POST `/enterprises/:E/assessments` | assessment | enterprise, assessment / 001, 004 | assessment | assessment list |
| GET, DELETE `/enterprises/:E/assessments/:A` | assessment | assessment / 004 | assessment | assessment detail |
| GET `/dashboard` | dashboard | enterprise, data-source, assessment / 001, 002, 004 | dashboard | home |
| GET, POST `/enterprises/:E/data-sources/:S/documents` | document | data-source, source-document / 002, 003 | document-schema, document-file, file-storage | data-sources page |
| GET `/enterprises/:E/data-sources/:S/documents/:D/content` | document | data-source, source-document / 002, 003 | document-schema | data-sources page |
| DELETE `/enterprises/:E/data-sources/:S/documents/:D` | document | data-source, source-document / 002, 003 | document-schema | data-sources page |

`routes.test.ts` exercises all 17 routes with mocked services; `http-contract.test.ts` checks selected response and error contracts. Document failure, ownership and reconciliation tests are in `document-service.test.ts`, `file-write-failure.test.ts` and `reconcile-files.test.ts`; `demo-guard.test.ts` tests the seed guard without executing the seed. The 41 database-independent tests do not prove real PostgreSQL behavior or file/database atomicity. Database integration, concurrency and file/database crash tests remain pending. DOCX checks verify ZIP structure and required entries but do not perform full OOXML validation.

The PostgreSQL-backed `runtime-dev.test.ts` subsequently exercised the 17 operations and selected persistence, file, concurrency and error cases; see [API_INTEGRATION_TEST_REPORT.md](API_INTEGRATION_TEST_REPORT.md). Real crash-boundary and uncertain-commit tests and the separate `_test` integration suite remain outstanding.
