# PostgreSQL integration status

## Phase 7 — development migration applied

The Windows PostgreSQL 18 service was observed running. After development configuration was supplied, a read-only connection confirmed database `maturity_app_dev`, role `maturity_user`, and PostgreSQL 18.7. Before migration no user tables, views, materialized views, foreign tables, or sequences were found. The separate `.env.demo` was not used for development.

The four migrations completed successfully with Sequelize CLI 6.6.5 and Sequelize 6.37.8. `SequelizeMeta` contains all four migration filenames. The four expected tables have identity integer keys, timezone-aware timestamps and the specified columns, nullability, defaults, indexes, CHECK constraints, unique storage key and three `ON DELETE RESTRICT` foreign keys. Schema metadata was inspected against the design; functional constraint, transaction and ORM behavior still require runtime testing. The application creates a Sequelize instance without authenticating at startup. The existing integration test requires a database name ending in `_test`; it cannot be run against development without an explicitly safe test strategy.

No migration rollback or destructive reset was performed. API, transaction and file/database checks use isolated test records and storage.

Initial independent checks: `npm run typecheck` passed; `npm test` passed 41 tests. These are not database integration tests.

## Subsequent runtime and demo checks

The development API workflow and constraint checks are recorded in [API_INTEGRATION_TEST_REPORT.md](API_INTEGRATION_TEST_REPORT.md). A transaction containing negative constraint tests was rolled back; no migration rollback or database reset occurred. After API test cleanup, all four development domain tables had zero rows.

The demo database was separately verified as `maturity_app_demo` under `maturity_user`, with no user relations before migration. Four migrations were applied, and the guarded demo seed was executed twice. The demo database then contained one enterprise, one source, no assessments and no documents; Development remained empty. Development and demo upload roots were created inside the backend workspace, checked as separate real paths by the seed guard and excluded from Git. Both environment files and `dist/` are ignored.

Typecheck and the newly added TypeScript build passed. The full existing integration suite was not run because its existing enterprise test requires a separate `_test` database, which was not created. Real crash and uncertain-commit tests remain outstanding.
