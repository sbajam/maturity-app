# Backend MVP decisions

- The existing `back/` contains the approved execution plan, but no backend implementation. Create the implementation in `backend/`, as specified by the plan, preserving `back/` and existing working-tree changes.
- The approved execution plan adopts `409 RESOURCE_NOT_EMPTY` and restricted foreign-key deletion for parents with dependent records, rather than the existing frontend mock's cascading deletion.
- Document upload is limited to PDF, DOCX and TXT with a default 20 MiB limit; filesystem/database crash recovery still requires real runtime verification.
- Only draft assessments and metadata are in scope. AI, scoring, external connectors and real frontend integration remain deferred.
- The primary API and database contracts govern endpoint and schema details; the execution plan specifies the order and current execution restrictions.
- Runtime integration uses uniquely named records in the approved Development database and an isolated temporary file root. The existing `_test`-only integration test is not pointed at Development; it remains pending until a dedicated test database or revised test strategy is authorized.
