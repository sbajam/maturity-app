# End-to-end workflow test report

## Outcome

**The requested end-to-end workflow is not complete.** This report records the observed behavior of the existing implementation; no new ingestion, capability import, context export or research features were implemented.

## Environment and checks

- Node 20.19.4 is the active system version; installed Nuxt 4.6.4 requires Node `^22.22.3 || ^24.15.0 || >=26.0.0`. Node 22.22.3 was used temporarily for the frontend checks without replacing the system version.
- Backend typecheck and build passed. Frontend build passed with Node 22.22.3. Frontend typecheck failed in existing `Timeline.vue`, `useMockStore.ts`, `tailwind.config.ts`, `utils/capability.ts` and `utils/format.ts`; the vue-router Volar plugin also reported an export-resolution warning.
- A read-only PostgreSQL connection confirmed `maturity_app_dev` and `maturity_user`. Nuxt on port 3000 and Express on port 3001 were started temporarily, and browser/API operations used Development.
- The 41 existing backend unit tests passed. No full PostgreSQL integration suite or crash tests were run in this turn.

## Observed workflow

| Check | Result |
|---|---|
| Create and open enterprise via browser | Passed; a uniquely named test enterprise was created and displayed. |
| Register source types | Seven requested types succeeded through the API: `clarity`, `matomo`, `support`, `business_document`, `capability_excel`, `server_log`, `event_log`. `analytics` returned 400. The existing contract has `custom` instead. |
| Refresh and persistence | The seven sources were visible after browser refresh. Assessment selection persistence could not be tested because selection is not implemented. |
| File upload/download | A TXT document on a Business Documentation source uploaded and downloaded successfully with matching content. A `.log` upload for Server Logs returned 415. Other formats and all supported-source combinations were not comprehensively tested in this turn. |
| Excel import | An OOXML `.xlsx` test workbook with a sheet and capability row was rejected with 415 by the Capability Excel upload endpoint. No capability extraction or preview was performed; there is no import implementation in the current source. |
| Draft assessment | Draft creation succeeded and the browser displayed it. Direct navigation to `/run` redirected back to draft details. |
| Organization isolation | Requesting the test document through a different existing enterprise returned 404. |
| API provider configuration | Ingestion method, provider credentials and actual connection-status configuration are absent from the current schema and API. No provider was connected or tested. |
| Stage 1 and Stage 2 | Not implemented in the real flow; source/capability selection and persistence after refresh could not be tested. |
| Assessment Context | No context-export endpoint or UI exists. No Markdown file was produced; completeness, credential exclusion and long-output behavior could not be evaluated. |
| Evidence & Mapping, AI Analysis, Results | The real run/report routes redirect to draft details. The separate `/demo` page shows labeled fixture results; it does not provide the requested three-step simulated wizard. No scientific result was written. |

The test enterprise and only its explicitly identified test sources, document and draft were deleted via the API. A final database count showed the pre-existing enterprise remained; no test enterprise remained. The temporary workbook and test servers were removed/stopped. No database was reset or dropped, and no migration or seed was run.

## Work required before Evidence & Mapping

The missing source types, ingestion method and status, expanded file handling, real XLSX import and mapping, persistent assessment selection, stages 1–2, complete context export and isolated simulated later steps require implementation before the requested workflow can be tested. The existing [schema proposal](SOURCE_INGESTION_SCHEMA_PROPOSAL.md) lists the identified shared paths and additive migration. It has not been applied. Frontend typecheck errors and the hardening items in [FRONTEND_INTEGRATION.md](FRONTEND_INTEGRATION.md) also remain.
