# Frontend integration — phase 10

Status: **In progress — runtime checks passed for selected workflows; full typecheck and complete integration coverage remain outstanding.** This is not a production-readiness decision.

| Stage | Implementation and verification |
|---|---|
| API infrastructure | `front/services/api.ts` and `useApi` provide typed API calls and error mapping. Server and browser use separately configurable runtime base URLs, defaulting to loopback port 3001. A local mock HTTP server verified pagination and 404 mapping. Browser mutations and SSR page loads were exercised against Development. |
| Enterprises | List, create, delete, pagination and overview use the real API; edit is disabled. Browser testing covered create, overview, delete, 404, and a rejected invalid create retaining its form. |
| Sources and documents | Source list, create, update, toggle and delete, and paginated document list, upload, download and delete use the API. Browser testing covered create, toggle, upload, downloaded content, delete and dependent-source 409. Multi-file, all error paths and pagination boundaries need further UI testing. |
| Assessments | Draft list/create/delete and detail use the API. Browser testing covered create, detail, delete and direct `run` redirection. Real run/report routes redirect to the draft and do not invoke the mock wizard. |
| Dashboard and reports | Dashboard reads global API counts; real reports and missing results show empty states. Dashboard was checked against Development in a browser. |
| Demo | `/demo` is a separate, explicitly labeled static fixture view enabled by `NUXT_PUBLIC_DEMO_MODE=true`; it does not write to the API. The older mock wizard and report files remain in the repository but their real routes redirect before page setup. The demo view is limited to sample assessment results, not the former wizard. SSR of the demo view was checked with a separate build process. |

Node active on the machine remains 20.19.4; Nuxt 4.6.4 requires Node `^22.22.3 || ^24.15.0 || >=26.0.0`. Node 22.22.3 was used temporarily through `npx`; `front/.nvmrc` records that version. TypeScript and vue-tsc were added for type checking, and ofetch is a direct dependency of the API client. The project-wide typecheck fails on existing `Timeline.vue`, `useMockStore.ts`, `tailwind.config.ts`, `utils/capability.ts` and `utils/format.ts` errors, with a vue-router Volar plugin resolution warning. No reported type errors were in the new integration files. The Nuxt production build passed under Node 22.22.3.

Temporary UI test records and the test upload were removed after the browser checks. The pre-existing Nuxt dev server was not stopped. No database reset, migration or seed was run during this phase. Crash recovery and the full PostgreSQL integration suite remain hardening tasks. Before declaring phase 10 complete, resolve the project typecheck failures and run repeatable end-to-end coverage for all pages, pagination, failures, demo isolation and SSR/browser navigation.

The later eight-source and assessment workflow requested by the user is not yet implemented. A new live check and its blocked steps are recorded in [END_TO_END_WORKFLOW_TEST_REPORT.md](END_TO_END_WORKFLOW_TEST_REPORT.md).
