# Frontend typecheck status

Status: **Failing — independent of the Source Ingestion design correction.**

The check was rerun on 2026-11-14 with temporary Node 22.22.3, compatible with installed Nuxt 4.6.4. The active system Node remains 20.19.4. The Nuxt typecheck exited with code 2 and reported:

- `front/components/assessment/Timeline.vue`, lines 80–91: five possibly-undefined accesses (`TS2532`).
- `front/composables/useMockStore.ts`, lines 203 and 553: partial objects are not assignable to the required entity types (`TS2322`).
- `front/tailwind.config.ts`, line 31: `require` is not recognized in the current type environment (`TS2591`, two occurrences).
- `front/utils/capability.ts`, lines 96, 103 and 104: possibly-undefined accesses (`TS2532`).
- `front/utils/format.ts`, line 32: source-type values do not all exist in the label map (`TS7053`).
- Vue language tooling additionally reports `ERR_PACKAGE_PATH_NOT_EXPORTED` for `vue-router/volar/sfc-route-blocks`.

These findings have not been fixed as part of the design-only correction. They require separate diagnosis and validation without changing the agreed source types or modifying dependencies solely to bypass the Node requirement. The previous successful frontend build does not make the typecheck pass.
