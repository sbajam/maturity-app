# Source ingestion and assessment context — reviewable schema proposal

This is a proposed migration and implementation boundary, not an applied migration. Existing Development and Demo data must remain intact. Inspection on 2026-11-14 found no Development sources and one Demo `business_document`; no records were changed. Counts may change before migration, so re-check immediately before applying it.

## Compatibility decisions

- The final source types are exactly the existing eight: `clarity`, `matomo`, `support`, `business_document`, `capability_excel`, `server_log`, `event_log`, and `custom`. `Custom` remains supported. There is no independent `analytics` source type; `Matomo Analytics` is the display name of `matomo`.
- Store ingestion method independently of type. A source may choose `file`, `api`, or be `unconfigured`; Server Logs and Event Logs support either choice. Existing records receive `unconfigured`, so the migration does not infer a connection or claim data has been ingested.
- API configuration is metadata only until a provider contract is approved. A configured endpoint is not an operational connector; report `Not Connected`. Do not accept or store credentials in these configuration fields.
- Preserve all existing document rows, source IDs, assessment IDs, permissions and download URLs. The existing 20 MiB upload limit remains the initial per-file limit.

## Proposed additive migration

`backend/migrations/005-add-ingestion-and-capabilities.cjs` should run in a transaction and:

1. Preserve the existing `data_sources_type_check` and its eight accepted values; do not add `analytics`, rename `custom`, or update existing type values.
2. Add `data_sources.ingestion_method varchar(16) NOT NULL DEFAULT 'unconfigured'` with a CHECK for `unconfigured`, `file`, `api`. Add nullable `api_base_url text`; validate scheme and reject userinfo, query and fragment at the API boundary. No password, token or connection-success flag is added.
3. Add `capability_imports`: identity PK; enterprise/source/document foreign keys with `ON DELETE RESTRICT`; sheet name, explicit column mapping, import status and timestamps. Add indexes for source and document ownership. A source document remains the original file of record.
4. Add `imported_capabilities`: identity PK; import FK `ON DELETE RESTRICT`; source row number; stable source key where supplied; name, optional description, optional parent reference and ordering fields; uniqueness on import and row. Persist validated rows and validation issues with source row numbers in `capability_import_issues`; do not infer a hierarchy from a fixed sheet layout.
5. Add `assessment_capabilities`: assessment FK and imported-capability FK with a composite unique key and ownership checked in the service; deleting an assessment removes only its selection links, not imported capability data. All assessment selections must reference capabilities belonging to the same enterprise.

The `down` operation must fail closed when new data exists, and must never delete existing source, document, assessment, import or selection data. Before running on either database, inspect the current schema, constraints and rows; back up, verify the database identity and apply the additive migration separately. Never alter or rerun the four existing migrations.

## File and export boundary

- Proposed accepted formats: Business Documentation PDF/DOCX/TXT; Capability Excel XLSX; Support, Clarity and Matomo CSV/JSON/XLSX; Server Logs and Event Logs TXT/LOG/CSV/JSON; Custom TXT/CSV/JSON/XLSX. The type/method/format policy belongs at the document service boundary, validated by extension, MIME and content. Existing document access remains valid. New parsing errors must not destroy the original upload.
- XLSX import must expose actual sheet names and columns before a user chooses mapping; read limits and invalid-row diagnostics are explicit. A persisted import points to the original `source_documents` record, and selection persists separately. No Evidence, score or AI result is stored.
- Context export is generated on the backend from owned records. A manifest identifies each source and file, selected capabilities, and available/unprocessed/missing content. CSV/JSON/XLSX inputs and textual source data are treated as untrusted data; include delimiters and an instruction that source text is not an instruction. API configuration credentials must never be included. When complete content exceeds a single-file limit, export a ZIP containing numbered Markdown parts and a manifest; do not silently truncate or summarize.
- Uploaded data can itself contain secrets. Filtering known credential fields and endpoint userinfo is necessary, but arbitrary text cannot be guaranteed secret-free by pattern matching. The export must not silently redact content; detected sensitive fields should block export with a clear error so they can be removed or explicitly handled under a separately agreed policy.

## Shared paths requiring explicit approval before writing

The existing rules require approval of each shared path and stated purpose. The following exact paths are presently identified:

| Path | Intended purpose and known consumers |
|---|---|
| `backend/package.json`, `backend/package-lock.json` | Add a maintained XLSX reader and streaming ZIP writer; affects installation and backend runtime. |
| `backend/migrations/005-add-ingestion-and-capabilities.cjs` | Additive PostgreSQL schema described above; affects Development, Demo and future databases. |
| `backend/src/models/data-source.model.ts`, `backend/src/models/index.ts` | Add method/configuration and register associations while retaining the existing eight types; used by all source, assessment, dashboard and document services. |
| `backend/src/models/capability-import.model.ts`, `backend/src/models/imported-capability.model.ts`, `backend/src/models/capability-import-issue.model.ts`, `backend/src/models/assessment-capability.model.ts` | Persist imports, diagnostics and selections; used by source import, assessment and context export. |
| `backend/src/schemas/data-source.schema.ts`, `backend/src/services/data-source.service.ts` | Validate and persist source type/method/configuration; affects source CRUD consumers. |
| `backend/src/services/document.service.ts` | Extend the existing shared upload/download service to approved types; affects all document consumers and filesystem recovery. |
| `backend/src/routes/index.ts` | Mount new capability-import, selection and context-export routes; affects API routing. |
| `front/types/datasource.ts`, `front/utils/data-source.ts`, `front/services/api.ts` | Retain the eight source types while adding method, labels and API client support for the source and assessment screens; affects all current consumers. |

Feature-specific controllers, services, routes, schemas, pages and tests will be added next to the existing features. No shared-client or shared-storage duplication will be introduced to avoid this approval requirement. If another shared path or a wider purpose is necessary, it requires a separate request.

Validation: compare model/migration/schema statically; unit-test file validation, XLSX mapping and invalid rows, selection ownership, export completeness and sensitive-data exclusion; run existing tests and typechecks; then apply the approved migration to Development and Demo only after preflight and test the complete browser workflow, refresh, ownership, rollback and download. Preserve all pre-existing records and files; do not reset or drop either database.

**Status: awaiting final approval.** No migration or schema change is authorized by this document alone.
