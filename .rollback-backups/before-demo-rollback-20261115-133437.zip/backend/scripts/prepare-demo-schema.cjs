'use strict';
const fs = require('node:fs');
const path = require('node:path');
const dotenv = require('dotenv');
const { Client } = require('pg');
const vm = require('node:vm');
const ts = require('typescript');

function readFixture(name, dependencies = {}) {
  const filename = path.resolve('../front/mock', `${name}.ts`);
  const source = ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  const exports = {};
  vm.runInNewContext(source, { exports, require: key => {
    if (!(key in dependencies)) throw new Error('Unexpected fixture dependency');
    return dependencies[key];
  } });
  return exports;
}

async function main() {
  const demo = dotenv.parse(fs.readFileSync(path.resolve('.env.demo')));
  const real = dotenv.parse(fs.readFileSync(path.resolve('.env')));
  const demoUrl = new URL(demo.DATABASE_URL);
  const realUrl = new URL(real.DATABASE_URL);
  const demoRoot = fs.realpathSync(path.resolve(demo.UPLOAD_ROOT));
  const realRoot = fs.realpathSync(path.resolve(real.UPLOAD_ROOT));
  const overlaps = (a, b) => {
    const relative = path.relative(a, b);
    return relative === '' || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
  };
  if (demo.APP_MODE !== 'demo' || demo.NODE_ENV === 'production' || !['127.0.0.1', 'localhost', '[::1]'].includes(demoUrl.hostname) || decodeURIComponent(demoUrl.pathname) !== '/maturity_app_demo' || demoUrl.pathname === realUrl.pathname || overlaps(demoRoot, realRoot) || overlaps(realRoot, demoRoot)) throw new Error('Demo isolation verification failed');
  const client = new Client({ connectionString: demo.DATABASE_URL });
  await client.connect();
  try {
    const identity = await client.query('SELECT current_database() AS name');
    if (identity.rows[0].name !== 'maturity_app_demo') throw new Error('Unexpected database');
    await client.query('BEGIN');
    await client.query(`CREATE TABLE IF NOT EXISTS demo_assessment_states (
      assessment_id integer PRIMARY KEY REFERENCES assessments(id) ON DELETE CASCADE,
      state jsonb NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now()
    )`);
    await client.query(`CREATE TABLE IF NOT EXISTS demo_fixtures (
      name text PRIMARY KEY,
      data jsonb NOT NULL
    )`);
    const fixture = JSON.parse(fs.readFileSync(path.resolve('../front/mock/vendow-capabilities.json'), 'utf8'));
    await client.query('INSERT INTO demo_fixtures (name, data) VALUES ($1, $2::jsonb) ON CONFLICT (name) DO NOTHING', ['vendow-capabilities', JSON.stringify(fixture)]);
    const enterprise = readFixture('enterprise');
    const datasets = {
      enterprise: enterprise.mockEnterprise,
      'data-sources': readFixture('data-sources', { './enterprise': enterprise }).mockDataSources,
      assessments: readFixture('assessments', { './enterprise': enterprise }).mockAssessments,
      capabilities: readFixture('capabilities').mockCapabilities,
      evidence: readFixture('evidence').mockEvidenceByAssessment,
      mappings: readFixture('mappings').mockMappingsByAssessment,
      'capability-assessments': readFixture('capability-assessments').mockCapabilityAssessmentsByAssessment,
      recommendations: readFixture('capability-assessments').mockRecommendationsByAssessment,
      pipelines: readFixture('pipeline').mockPipelines,
    };
    for (const [name, data] of Object.entries(datasets)) {
      if (data === undefined) throw new Error('Missing fixture');
      await client.query('INSERT INTO demo_fixtures (name, data) VALUES ($1, $2::jsonb) ON CONFLICT (name) DO NOTHING', [`frontend-mock-${name}`, JSON.stringify(data)]);
    }
    for (const [name, filename, mediaType] of [
      ['vendow-workbook', 'vendow-capabilities.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
      ['vendow-document', 'vendow-document.pdf', 'application/pdf'],
    ]) {
      const bytes = fs.readFileSync(path.resolve('../front/public/demo/fixtures', filename));
      await client.query('INSERT INTO demo_fixtures (name, data) VALUES ($1, $2::jsonb) ON CONFLICT (name) DO NOTHING', [name, JSON.stringify({ filename, mediaType, base64: bytes.toString('base64') })]);
    }
    await client.query('COMMIT');
    console.log('Demo schema and capability fixture ready.');
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    throw error;
  } finally { await client.end(); }
}
main().catch(() => { console.error('Demo preparation failed; no changes committed.'); process.exitCode = 1; });
