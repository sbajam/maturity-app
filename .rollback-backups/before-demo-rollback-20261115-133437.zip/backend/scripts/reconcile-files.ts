import 'dotenv/config';
import path from 'node:path';
import { parseEnv } from '../src/config/env.js';
import { createDatabase } from '../src/config/database.js';
import { initModels, SourceDocument } from '../src/models/index.js';
import { reconcileFiles } from '../src/utils/reconcile-files.js';

async function main() {
  if (!process.argv.includes('--writers-stopped')) throw new Error('Stop all writers and pass --writers-stopped');
  const env = parseEnv(process.env); const db = createDatabase(env); initModels(db);
  try {
    const records = await SourceDocument.findAll({ attributes: ['storageKey'] });
    const messages = await reconcileFiles(path.resolve(env.UPLOAD_ROOT), new Set(records.map(record => record.storageKey)));
    for (const message of messages) console.info(message);
  } finally { await db.close(); }
}
main().catch(() => { console.error('Reconciliation failed'); process.exitCode = 1; });
