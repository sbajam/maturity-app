import 'dotenv/config';
import { parseEnv } from '../src/config/env.js';
import { createDatabase } from '../src/config/database.js';
import { DataSource, Enterprise, initModels } from '../src/models/index.js';
import { assertDemoIsolation } from '../src/utils/demo-guard.js';

async function main() {
  const env = parseEnv(process.env);
  await assertDemoIsolation(env, process.env.REAL_DATABASE_URL, process.env.REAL_UPLOAD_ROOT);
  const db = createDatabase(env); initModels(db);
  try {
    await db.transaction(async transaction => {
      await Enterprise.upsert({ id: 1000000001, name: 'Demo enterprise', industry: 'Software', description: null, country: null, businessModel: null, companySize: null }, { transaction });
      await DataSource.upsert({ id: 1000000001, enterpriseId: 1000000001, name: 'Demo business context', type: 'business_document', enabled: true, description: null, businessText: null }, { transaction });
    });
  } finally { await db.close(); }
}

main().catch(() => { console.error('Demo seed failed'); process.exitCode = 1; });
