import express from 'express';
import cors from 'cors';
import { rateLimit } from 'express-rate-limit';
import type { AppEnv } from './config/env.js';
import { apiRoutes } from './routes/index.js';
import { notFound } from './middlewares/not-found.js';
import { errorHandler } from './middlewares/error-handler.js';
import { demoRoutes } from './routes/demo.routes.js';

export function createApp(env: AppEnv) {
  const app = express();
  app.disable('x-powered-by');
  app.use(cors({ origin: env.CORS_ORIGIN }));
  app.use('/api/v1', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: { code: 'RATE_LIMITED', message: 'Too many requests' } } }));
  app.use(express.json({ limit: '1mb' }));
  app.use((_req, res, next) => { res.locals.env = env; next(); });
  if (env.APP_MODE === 'demo') app.use('/api/v1/demo', demoRoutes);
  app.use('/api/v1', apiRoutes);
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
