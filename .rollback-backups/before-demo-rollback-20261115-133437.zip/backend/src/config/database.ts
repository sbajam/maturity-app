import { Sequelize } from 'sequelize';
import type { AppEnv } from './env.js';

export function createDatabase(env: AppEnv): Sequelize {
  return new Sequelize(env.DATABASE_URL, { dialect: 'postgres', logging: false });
}
