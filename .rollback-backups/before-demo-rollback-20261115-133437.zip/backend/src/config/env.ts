import { z } from 'zod';

function parseUrl(value: string): URL | undefined {
  try { return new URL(value); } catch { return undefined; }
}

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  APP_MODE: z.enum(['real', 'demo']).default('real'),
  HOST: z.enum(['127.0.0.1', '::1', 'localhost']).default('127.0.0.1'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3001),
  DATABASE_URL: z.string().url().refine(value => ['postgres:', 'postgresql:'].includes(parseUrl(value)?.protocol ?? '')),
  CORS_ORIGIN: z.string().url().refine(value => {
    const url = parseUrl(value);
    return url !== undefined && ['http:', 'https:'].includes(url.protocol) && url.origin === value;
  }),
  UPLOAD_ROOT: z.string().trim().min(1),
  MAX_UPLOAD_BYTES: z.coerce.number().int().min(1).max(20971520).default(20971520),
}).superRefine((value, context) => {
  if (value.NODE_ENV === 'production' && value.APP_MODE === 'demo') {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ['APP_MODE'], message: 'Demo mode is not allowed in production' });
  }
});

export type AppEnv = z.infer<typeof envSchema>;
export function parseEnv(input: NodeJS.ProcessEnv): AppEnv {
  return envSchema.parse(input);
}
