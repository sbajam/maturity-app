export type ErrorCode = 'VALIDATION_ERROR' | 'NOT_FOUND' | 'RESOURCE_NOT_EMPTY' | 'FILE_TOO_LARGE' | 'UNSUPPORTED_FILE_TYPE' | 'INTERNAL_ERROR' | 'SERVICE_UNAVAILABLE';
export type ErrorField = { path: string; message: string };

export class AppError extends Error {
  constructor(public readonly status: number, public readonly code: ErrorCode, message: string, public readonly fields?: ErrorField[]) {
    super(message);
    this.name = 'AppError';
  }
}
