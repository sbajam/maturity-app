import type { Response } from 'express';

export function respond<T>(res: Response, data: T, status = 200): Response {
  return res.status(status).json({ data });
}

export function respondList<T>(res: Response, data: T[], pagination: { page: number; pageSize: number; total: number }): Response {
  return res.json({ data, pagination });
}
