import type { RequestHandler } from 'express';
import { respond, respondList } from '../contracts/http.js';
import * as service from '../services/assessment.service.js';

export const list: RequestHandler = async (_req, res) => {
  const { enterpriseId } = res.locals.validated.params;
  const { page, pageSize } = res.locals.validated.query;
  const result = await service.listAssessments(enterpriseId, page, pageSize);
  respondList(res, result.data, result.pagination);
};
export const create: RequestHandler = async (_req, res) => { respond(res, await service.createAssessment(res.locals.validated.params.enterpriseId, res.locals.validated.body), 201); };
export const get: RequestHandler = async (_req, res) => {
  const { enterpriseId, assessmentId } = res.locals.validated.params;
  respond(res, await service.getAssessment(enterpriseId, assessmentId));
};
export const remove: RequestHandler = async (_req, res) => {
  const { enterpriseId, assessmentId } = res.locals.validated.params;
  await service.removeAssessment(enterpriseId, assessmentId);
  res.sendStatus(204);
};
