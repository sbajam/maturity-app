import type { RequestHandler } from 'express';
import { respond } from '../contracts/http.js';
import { dashboardSummary } from '../services/dashboard.service.js';

export const summary: RequestHandler = async (_req, res) => { respond(res, await dashboardSummary()); };
