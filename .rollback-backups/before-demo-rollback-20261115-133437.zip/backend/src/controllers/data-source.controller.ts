import type { RequestHandler } from 'express';
import { respond, respondList } from '../contracts/http.js';
import * as service from '../services/data-source.service.js';

export const list: RequestHandler = async (_req, res) => {
  const { enterpriseId } = res.locals.validated.params;
  const { page, pageSize } = res.locals.validated.query;
  const result = await service.listDataSources(enterpriseId, page, pageSize);
  respondList(res, result.data, result.pagination);
};
export const create: RequestHandler = async (_req, res) => { respond(res, await service.createDataSource(res.locals.validated.params.enterpriseId, res.locals.validated.body), 201); };
export const update: RequestHandler = async (_req, res) => {
  const { enterpriseId, sourceId } = res.locals.validated.params;
  respond(res, await service.updateDataSource(enterpriseId, sourceId, res.locals.validated.body));
};
export const remove: RequestHandler = async (_req, res) => {
  const { enterpriseId, sourceId } = res.locals.validated.params;
  await service.removeDataSource(enterpriseId, sourceId);
  res.sendStatus(204);
};
