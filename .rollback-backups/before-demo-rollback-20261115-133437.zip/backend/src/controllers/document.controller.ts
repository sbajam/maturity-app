import type { RequestHandler } from 'express';
import { respond, respondList } from '../contracts/http.js';
import { AppError } from '../contracts/errors.js';
import * as service from '../services/document.service.js';

export const list: RequestHandler = async (_req, res) => {
  const { enterpriseId, sourceId } = res.locals.validated.params;
  const { page, pageSize } = res.locals.validated.query;
  const result = await service.listDocuments(enterpriseId, sourceId, page, pageSize);
  respondList(res, result.data, result.pagination);
};
export const upload: RequestHandler = async (req, res) => {
  const { enterpriseId, sourceId } = res.locals.validated.params;
  if (!req.file) throw new AppError(400, 'VALIDATION_ERROR', 'A file is required');
  respond(res, await service.uploadDocument(enterpriseId, sourceId, req.file, res.locals.env.UPLOAD_ROOT, res.locals.env.MAX_UPLOAD_BYTES), 201);
};
export const download: RequestHandler = async (_req, res, next) => {
  const { enterpriseId, sourceId, documentId } = res.locals.validated.params;
  const { document, file } = await service.downloadDocument(enterpriseId, sourceId, documentId, res.locals.env.UPLOAD_ROOT);
  res.attachment(document.originalName);
  res.setHeader('Content-Type', document.mediaType);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  const stream = file.createReadStream();
  stream.on('error', next);
  stream.pipe(res);
};
export const remove: RequestHandler = async (_req, res) => {
  const { enterpriseId, sourceId, documentId } = res.locals.validated.params;
  await service.removeDocument(enterpriseId, sourceId, documentId, res.locals.env.UPLOAD_ROOT);
  res.sendStatus(204);
};
