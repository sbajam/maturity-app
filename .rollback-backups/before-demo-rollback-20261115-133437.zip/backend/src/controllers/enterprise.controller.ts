import type { RequestHandler } from 'express';
import { respond, respondList } from '../contracts/http.js';
import * as service from '../services/enterprise.service.js';

export const list: RequestHandler = async (_req, res) => {
  const { page, pageSize } = res.locals.validated.query;
  const result = await service.listEnterprises(page, pageSize);
  respondList(res, result.data, result.pagination);
};
export const create: RequestHandler = async (_req, res) => { respond(res, await service.createEnterprise(res.locals.validated.body), 201); };
export const get: RequestHandler = async (_req, res) => { respond(res, await service.getEnterprise(res.locals.validated.params.enterpriseId)); };
export const remove: RequestHandler = async (_req, res) => { await service.removeEnterprise(res.locals.validated.params.enterpriseId); res.sendStatus(204); };
