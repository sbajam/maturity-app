import type { ErrorRequestHandler } from 'express';
import { ConnectionError, ForeignKeyConstraintError } from 'sequelize';
import { AppError } from '../contracts/errors.js';
import { logger } from '../config/logger.js';
import multer from 'multer';

export const errorHandler: ErrorRequestHandler = (error: unknown, _req, res, next) => {
  if (res.headersSent) return next(error);
  let failure: AppError;
  if (error instanceof AppError) failure = error;
  else if (error instanceof multer.MulterError) failure = error.code === 'LIMIT_FILE_SIZE' ? new AppError(413, 'FILE_TOO_LARGE', 'File too large') : new AppError(400, 'VALIDATION_ERROR', 'Invalid input');
  else if (error instanceof Error && 'code' in error && ['ENOENT', 'ENOTDIR', 'EACCES', 'ENOSPC', 'EIO'].includes(String(error.code))) failure = new AppError(503, 'SERVICE_UNAVAILABLE', 'Service unavailable');
  else if (error instanceof ConnectionError) failure = new AppError(503, 'SERVICE_UNAVAILABLE', 'Service unavailable');
  else if (error instanceof ForeignKeyConstraintError) failure = new AppError(409, 'RESOURCE_NOT_EMPTY', 'Resource has dependent records');
  else if (error instanceof SyntaxError && 'status' in error && error.status === 400) failure = new AppError(400, 'VALIDATION_ERROR', 'Invalid input');
  else {
    logger.error('Unhandled request error');
    failure = new AppError(500, 'INTERNAL_ERROR', 'Internal server error');
  }
  res.status(failure.status).json({ error: { code: failure.code, message: failure.message, ...(failure.fields ? { fields: failure.fields } : {}) } });
};
