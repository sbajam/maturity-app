import type { RequestHandler } from 'express';
import type { ZodTypeAny } from 'zod';
import { AppError } from '../contracts/errors.js';

export function validate(schemas: { params?: ZodTypeAny; query?: ZodTypeAny; body?: ZodTypeAny }): RequestHandler {
  return (req, res, next) => {
    const validated: Record<string, unknown> = {};
    for (const key of ['params', 'query', 'body'] as const) {
      const schema = schemas[key];
      if (!schema) continue;
      const result = schema.safeParse(req[key]);
      if (!result.success) {
        return next(new AppError(400, 'VALIDATION_ERROR', 'Invalid input', result.error.issues.map(issue => ({ path: issue.path.join('.'), message: issue.message }))));
      }
      validated[key] = result.data;
    }
    res.locals.validated = validated;
    next();
  };
}
