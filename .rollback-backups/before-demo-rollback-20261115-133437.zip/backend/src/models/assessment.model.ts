import { DataTypes, Model, Sequelize, type InferAttributes, type InferCreationAttributes, type CreationOptional, type NonAttribute } from 'sequelize';
import type { Enterprise } from './enterprise.model.js';

export class Assessment extends Model<InferAttributes<Assessment>, InferCreationAttributes<Assessment>> {
  declare id: CreationOptional<number>;
  declare enterpriseId: number;
  declare name: string;
  declare description: string | null;
  declare version: CreationOptional<string>;
  declare status: CreationOptional<'draft'>;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
  declare enterprise?: NonAttribute<Enterprise>;
}

export function initAssessment(sequelize: Sequelize): void {
  Assessment.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    enterpriseId: { type: DataTypes.INTEGER, allowNull: false },
    name: { type: DataTypes.STRING(200), allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: true },
    version: { type: DataTypes.STRING(40), allowNull: false, defaultValue: '1.0' },
    status: { type: DataTypes.STRING(16), allowNull: false, defaultValue: 'draft' },
    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
  }, { sequelize, tableName: 'assessments', underscored: true });
}
