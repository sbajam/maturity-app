import { DataTypes, Model, Sequelize, type InferAttributes, type InferCreationAttributes, type CreationOptional, type NonAttribute } from 'sequelize';
import type { SourceDocument } from './source-document.model.js';
import type { Enterprise } from './enterprise.model.js';

export type DataSourceType = 'clarity' | 'matomo' | 'support' | 'business_document' | 'capability_excel' | 'server_log' | 'event_log' | 'custom';

export class DataSource extends Model<InferAttributes<DataSource>, InferCreationAttributes<DataSource>> {
  declare id: CreationOptional<number>;
  declare enterpriseId: number;
  declare name: string;
  declare type: DataSourceType;
  declare enabled: CreationOptional<boolean>;
  declare description: string | null;
  declare businessText: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
  declare enterprise?: NonAttribute<Enterprise>;
  declare documents?: NonAttribute<SourceDocument[]>;
}

export function initDataSource(sequelize: Sequelize): void {
  DataSource.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    enterpriseId: { type: DataTypes.INTEGER, allowNull: false },
    name: { type: DataTypes.STRING(200), allowNull: false },
    type: { type: DataTypes.STRING(32), allowNull: false },
    enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
    description: { type: DataTypes.TEXT, allowNull: true },
    businessText: { type: DataTypes.TEXT, allowNull: true },
    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
  }, { sequelize, tableName: 'data_sources', underscored: true });
}
