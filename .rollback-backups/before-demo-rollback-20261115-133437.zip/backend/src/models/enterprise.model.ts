import { DataTypes, Model, Sequelize, type InferAttributes, type InferCreationAttributes, type CreationOptional, type NonAttribute } from 'sequelize';
import type { DataSource } from './data-source.model.js';
import type { Assessment } from './assessment.model.js';

export class Enterprise extends Model<InferAttributes<Enterprise>, InferCreationAttributes<Enterprise>> {
  declare id: CreationOptional<number>;
  declare name: string;
  declare industry: string;
  declare description: string | null;
  declare country: string | null;
  declare businessModel: string | null;
  declare companySize: string | null;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
  declare dataSources?: NonAttribute<DataSource[]>;
  declare assessments?: NonAttribute<Assessment[]>;
}

export function initEnterprise(sequelize: Sequelize): void {
  Enterprise.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(200), allowNull: false },
    industry: { type: DataTypes.STRING(200), allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: true },
    country: { type: DataTypes.STRING(120), allowNull: true },
    businessModel: { type: DataTypes.STRING(120), allowNull: true },
    companySize: { type: DataTypes.STRING(20), allowNull: true },
    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
  }, { sequelize, tableName: 'enterprises', underscored: true });
}
