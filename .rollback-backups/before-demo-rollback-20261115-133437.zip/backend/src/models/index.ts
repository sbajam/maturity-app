import type { Sequelize } from 'sequelize';
import { Enterprise, initEnterprise } from './enterprise.model.js';
import { DataSource, initDataSource } from './data-source.model.js';
import { SourceDocument, initSourceDocument } from './source-document.model.js';
import { Assessment, initAssessment } from './assessment.model.js';

export function initModels(sequelize: Sequelize): void {
  initEnterprise(sequelize);
  initDataSource(sequelize);
  initSourceDocument(sequelize);
  initAssessment(sequelize);
  Enterprise.hasMany(DataSource, { foreignKey: 'enterpriseId', as: 'dataSources', onDelete: 'RESTRICT' });
  DataSource.belongsTo(Enterprise, { foreignKey: 'enterpriseId', as: 'enterprise', onDelete: 'RESTRICT' });
  Enterprise.hasMany(Assessment, { foreignKey: 'enterpriseId', as: 'assessments', onDelete: 'RESTRICT' });
  Assessment.belongsTo(Enterprise, { foreignKey: 'enterpriseId', as: 'enterprise', onDelete: 'RESTRICT' });
  DataSource.hasMany(SourceDocument, { foreignKey: 'dataSourceId', as: 'documents', onDelete: 'RESTRICT' });
  SourceDocument.belongsTo(DataSource, { foreignKey: 'dataSourceId', as: 'dataSource', onDelete: 'RESTRICT' });
}

export { Enterprise, DataSource, SourceDocument, Assessment };
