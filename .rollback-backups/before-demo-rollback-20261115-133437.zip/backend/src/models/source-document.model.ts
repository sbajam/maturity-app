import { DataTypes, Model, Sequelize, type InferAttributes, type InferCreationAttributes, type CreationOptional, type NonAttribute } from 'sequelize';
import type { DataSource } from './data-source.model.js';

export class SourceDocument extends Model<InferAttributes<SourceDocument>, InferCreationAttributes<SourceDocument>> {
  declare id: CreationOptional<number>;
  declare dataSourceId: number;
  declare storageKey: string;
  declare originalName: string;
  declare mediaType: string;
  declare sizeBytes: number;
  declare sha256: string;
  declare createdAt: CreationOptional<Date>;
  declare updatedAt: CreationOptional<Date>;
  declare dataSource?: NonAttribute<DataSource>;
}

export function initSourceDocument(sequelize: Sequelize): void {
  SourceDocument.init({
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    dataSourceId: { type: DataTypes.INTEGER, allowNull: false },
    storageKey: { type: DataTypes.UUID, allowNull: false, unique: true },
    originalName: { type: DataTypes.STRING(255), allowNull: false },
    mediaType: { type: DataTypes.STRING(100), allowNull: false },
    sizeBytes: { type: DataTypes.INTEGER, allowNull: false },
    sha256: { type: DataTypes.CHAR(64), allowNull: false },
    createdAt: { type: DataTypes.DATE, allowNull: false },
    updatedAt: { type: DataTypes.DATE, allowNull: false },
  }, { sequelize, tableName: 'source_documents', underscored: true });
}
