import { Router } from 'express';
import { z } from 'zod';
import * as controller from '../controllers/assessment.controller.js';
import { validate } from '../middlewares/validate.js';
import { idSchema, paginationSchema } from '../schemas/common.schema.js';
import { assessmentSchema } from '../schemas/assessment.schema.js';

export const assessmentRoutes = Router({ mergeParams: true });
const parent = z.object({ enterpriseId: idSchema }).strict();
const child = parent.extend({ assessmentId: idSchema }).strict();
assessmentRoutes.get('/', validate({ params: parent, query: paginationSchema }), controller.list);
assessmentRoutes.post('/', validate({ params: parent, body: assessmentSchema }), controller.create);
assessmentRoutes.get('/:assessmentId', validate({ params: child }), controller.get);
assessmentRoutes.delete('/:assessmentId', validate({ params: child }), controller.remove);
