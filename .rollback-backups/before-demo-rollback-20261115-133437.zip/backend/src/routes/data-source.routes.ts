import { Router } from 'express';
import { z } from 'zod';
import * as controller from '../controllers/data-source.controller.js';
import { validate } from '../middlewares/validate.js';
import { idSchema, paginationSchema } from '../schemas/common.schema.js';
import { dataSourceCreateSchema, dataSourcePatchSchema } from '../schemas/data-source.schema.js';

export const dataSourceRoutes = Router({ mergeParams: true });
const parent = z.object({ enterpriseId: idSchema }).strict();
const child = parent.extend({ sourceId: idSchema }).strict();
dataSourceRoutes.get('/', validate({ params: parent, query: paginationSchema }), controller.list);
dataSourceRoutes.post('/', validate({ params: parent, body: dataSourceCreateSchema }), controller.create);
dataSourceRoutes.patch('/:sourceId', validate({ params: child, body: dataSourcePatchSchema }), controller.update);
dataSourceRoutes.delete('/:sourceId', validate({ params: child }), controller.remove);
