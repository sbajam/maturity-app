import { Router } from 'express';
import { QueryTypes } from 'sequelize';
import { z } from 'zod';
import { Assessment, DataSource } from '../models/index.js';
import { AppError } from '../contracts/errors.js';

export const demoRoutes = Router();
const stateSchema = z.object({
  step: z.number().int().min(1).max(5),
  sourceIds: z.array(z.number().int().positive()).max(1000),
  leafIds: z.array(z.string().min(1).max(100)).max(10000),
  scope: z.string().max(1000),
  notes: z.string().max(10000),
}).strict();

demoRoutes.use(async (_req, res, next) => {
  const env = res.locals.env;
  const url = new URL(env.DATABASE_URL);
  const db = Assessment.sequelize;
  if (env.APP_MODE !== 'demo' || env.NODE_ENV === 'production' || !db || !['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || decodeURIComponent(url.pathname) !== '/maturity_app_demo') return next(new AppError(404, 'NOT_FOUND', 'Resource not found'));
  const rows = await db.query<{ name: string }>('SELECT current_database() AS name', { type: QueryTypes.SELECT });
  if (rows[0]?.name !== 'maturity_app_demo') return next(new AppError(404, 'NOT_FOUND', 'Resource not found'));
  next();
});

demoRoutes.get('/capabilities', async (_req, res) => {
  const db = Assessment.sequelize!;
  const rows = await db.query<{ data: object }>('SELECT data FROM demo_fixtures WHERE name = $1', { bind: ['vendow-capabilities'], type: QueryTypes.SELECT });
  if (!rows[0]) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  res.json({ data: rows[0].data });
});

demoRoutes.get('/fixtures/:name/content', async (req, res) => {
  if (!['vendow-workbook', 'vendow-document'].includes(req.params.name)) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  const rows = await Assessment.sequelize!.query<{ data: { filename: string; mediaType: string; base64: string } }>('SELECT data FROM demo_fixtures WHERE name = $1', { bind: [req.params.name], type: QueryTypes.SELECT });
  if (!rows[0]) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  res.type(rows[0].data.mediaType).attachment(rows[0].data.filename).send(Buffer.from(rows[0].data.base64, 'base64'));
});

demoRoutes.route('/enterprises/:enterpriseId/assessments/:assessmentId/state')
  .get(async (req, res) => {
    const enterpriseId = Number(req.params.enterpriseId); const assessmentId = Number(req.params.assessmentId);
    if (!Number.isSafeInteger(enterpriseId) || !Number.isSafeInteger(assessmentId) || enterpriseId < 1 || assessmentId < 1 || !await Assessment.findOne({ where: { id: assessmentId, enterpriseId } })) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    const rows = await Assessment.sequelize!.query<{ state: object }>('SELECT state FROM demo_assessment_states WHERE assessment_id = $1', { bind: [assessmentId], type: QueryTypes.SELECT });
    res.json({ data: rows[0]?.state ?? null });
  })
  .put(async (req, res) => {
    const enterpriseId = Number(req.params.enterpriseId); const assessmentId = Number(req.params.assessmentId);
    if (!Number.isSafeInteger(enterpriseId) || !Number.isSafeInteger(assessmentId) || enterpriseId < 1 || assessmentId < 1 || !await Assessment.findOne({ where: { id: assessmentId, enterpriseId } })) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    const parsed = stateSchema.safeParse(req.body);
    if (!parsed.success) throw new AppError(400, 'VALIDATION_ERROR', 'Invalid input');
    const sourceIds = [...new Set(parsed.data.sourceIds)];
    const ownedSources = await DataSource.count({ where: { enterpriseId, id: sourceIds } });
    if (ownedSources !== sourceIds.length) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    const fixtures = await Assessment.sequelize!.query<{ data: { id: string; parentId: string | null }[] }>('SELECT data FROM demo_fixtures WHERE name = $1', { bind: ['vendow-capabilities'], type: QueryTypes.SELECT });
    const nodes = fixtures[0]?.data;
    if (!nodes) throw new AppError(503, 'SERVICE_UNAVAILABLE', 'Demo fixture unavailable');
    const parents = new Set(nodes.map(node => node.parentId));
    const leaves = new Set(nodes.filter(node => !parents.has(node.id)).map(node => node.id));
    if (parsed.data.leafIds.some(id => !leaves.has(id))) throw new AppError(400, 'VALIDATION_ERROR', 'Invalid capability selection');
    await Assessment.sequelize!.query('INSERT INTO demo_assessment_states (assessment_id, state) VALUES ($1, $2::jsonb) ON CONFLICT (assessment_id) DO UPDATE SET state = EXCLUDED.state, updated_at = now()', { bind: [assessmentId, JSON.stringify(parsed.data)] });
    res.json({ data: parsed.data });
  });
