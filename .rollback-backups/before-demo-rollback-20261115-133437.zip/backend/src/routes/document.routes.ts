import { Router } from 'express';
import multer from 'multer';
import * as controller from '../controllers/document.controller.js';
import { validate } from '../middlewares/validate.js';
import { paginationSchema } from '../schemas/common.schema.js';
import { documentItemParamsSchema, documentParentParamsSchema } from '../schemas/document.schema.js';

export const documentRoutes = Router({ mergeParams: true });
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20971520, files: 1, fields: 0 } });
documentRoutes.get('/', validate({ params: documentParentParamsSchema, query: paginationSchema }), controller.list);
documentRoutes.post('/', validate({ params: documentParentParamsSchema }), upload.single('file'), controller.upload);
documentRoutes.get('/:documentId/content', validate({ params: documentItemParamsSchema }), controller.download);
documentRoutes.delete('/:documentId', validate({ params: documentItemParamsSchema }), controller.remove);
