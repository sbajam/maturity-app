import { Router } from 'express';
import { z } from 'zod';
import * as controller from '../controllers/enterprise.controller.js';
import { validate } from '../middlewares/validate.js';
import { idSchema, paginationSchema } from '../schemas/common.schema.js';
import { enterpriseSchema } from '../schemas/enterprise.schema.js';

export const enterpriseRoutes = Router();
const params = z.object({ enterpriseId: idSchema }).strict();
enterpriseRoutes.get('/', validate({ query: paginationSchema }), controller.list);
enterpriseRoutes.post('/', validate({ body: enterpriseSchema }), controller.create);
enterpriseRoutes.get('/:enterpriseId', validate({ params }), controller.get);
enterpriseRoutes.delete('/:enterpriseId', validate({ params }), controller.remove);
