import { Router } from 'express';
import { enterpriseRoutes } from './enterprise.routes.js';
import { dataSourceRoutes } from './data-source.routes.js';
import { assessmentRoutes } from './assessment.routes.js';
import { dashboardRoutes } from './dashboard.routes.js';
import { documentRoutes } from './document.routes.js';

export const apiRoutes = Router();
apiRoutes.use('/enterprises/:enterpriseId/data-sources/:sourceId/documents', documentRoutes);
apiRoutes.use('/enterprises/:enterpriseId/data-sources', dataSourceRoutes);
apiRoutes.use('/enterprises/:enterpriseId/assessments', assessmentRoutes);
apiRoutes.use('/enterprises', enterpriseRoutes);
apiRoutes.use('/dashboard', dashboardRoutes);
