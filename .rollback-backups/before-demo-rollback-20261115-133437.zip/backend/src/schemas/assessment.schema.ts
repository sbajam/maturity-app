import { z } from 'zod';

export const assessmentSchema = z.object({
  name: z.string().trim().min(1).max(200),
  description: z.string().trim().max(10000).transform(value => value || null).nullable().optional().default(null),
  version: z.string().trim().min(1).max(40).optional().default('1.0'),
}).strict();
