import { z } from 'zod';

const positiveInteger = z.string().regex(/^[1-9]\d*$/).transform(Number).refine(Number.isSafeInteger).refine(value => value <= 2147483647);
export const idSchema = positiveInteger;
export const paginationSchema = z.object({
  page: positiveInteger.default('1'),
  pageSize: positiveInteger.refine(value => value <= 100).default('20'),
}).strict();
