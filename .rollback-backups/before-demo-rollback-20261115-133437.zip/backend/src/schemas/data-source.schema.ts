import { z } from 'zod';

const sourceTypes = ['clarity', 'matomo', 'support', 'business_document', 'capability_excel', 'server_log', 'event_log', 'custom'] as const;
const text = (max: number) => z.string().trim().max(max).transform(value => value || null).nullable();

export const dataSourceCreateSchema = z.object({
  name: z.string().trim().min(1).max(200),
  type: z.enum(sourceTypes),
  description: text(10000).optional().default(null),
  businessText: text(50000).optional().default(null),
  enabled: z.boolean().optional().default(true),
}).strict().refine(value => value.type === 'business_document' || value.businessText === null, {
  path: ['businessText'], message: 'Business text requires a business document source',
});

export const dataSourcePatchSchema = z.object({
  description: text(10000).optional(),
  businessText: text(50000).optional(),
  enabled: z.boolean().optional(),
}).strict().refine(value => Object.keys(value).length > 0, { message: 'At least one field is required' });
