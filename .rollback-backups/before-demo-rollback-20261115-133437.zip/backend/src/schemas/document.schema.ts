import { z } from 'zod';
import { idSchema } from './common.schema.js';

export const documentParentParamsSchema = z.object({
  enterpriseId: idSchema,
  sourceId: idSchema,
}).strict();

export const documentItemParamsSchema = documentParentParamsSchema.extend({ documentId: idSchema }).strict();
