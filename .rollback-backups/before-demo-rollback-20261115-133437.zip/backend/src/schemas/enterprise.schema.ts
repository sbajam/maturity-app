import { z } from 'zod';

const optionalText = (max: number) => z.string().trim().max(max).transform(value => value || null).nullable().optional().default(null);

export const enterpriseSchema = z.object({
  name: z.string().trim().min(1).max(200),
  industry: z.string().trim().min(1).max(200),
  description: optionalText(10000),
  country: optionalText(120),
  businessModel: optionalText(120),
  companySize: z.enum(['1-10', '11-50', '51-200', '201-500', '500+']).nullable().optional().default(null),
}).strict();
