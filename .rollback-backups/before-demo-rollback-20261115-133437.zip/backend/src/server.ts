import 'dotenv/config';
import { createApp } from './app.js';
import { parseEnv } from './config/env.js';
import { logger } from './config/logger.js';
import { createDatabase } from './config/database.js';
import { initModels } from './models/index.js';
import { assertDemoIsolation } from './utils/demo-guard.js';

const env = parseEnv(process.env);
const database = createDatabase(env);
if (env.APP_MODE === 'demo') {
  const url = new URL(env.DATABASE_URL);
  if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || decodeURIComponent(url.pathname) !== '/maturity_app_demo') throw new Error('Invalid demo database');
  await assertDemoIsolation(env, process.env.REAL_DATABASE_URL, process.env.REAL_UPLOAD_ROOT);
  const [rows] = await database.query('SELECT current_database() AS name');
  if (!Array.isArray(rows) || (rows[0] as { name?: string } | undefined)?.name !== 'maturity_app_demo') throw new Error('Invalid demo database');
}
initModels(database);
const server = createApp(env).listen(env.PORT, env.HOST, () => logger.info('Backend listening on loopback'));
for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => server.close(() => { void database.close().finally(() => process.exit(0)); }));
}
