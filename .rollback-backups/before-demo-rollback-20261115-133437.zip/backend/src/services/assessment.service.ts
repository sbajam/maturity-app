import type { z } from 'zod';
import { AppError } from '../contracts/errors.js';
import { Assessment, Enterprise } from '../models/index.js';
import type { assessmentSchema } from '../schemas/assessment.schema.js';
import { defaultOrder, pagination } from '../utils/pagination.js';

export async function listAssessments(enterpriseId: number, page: number, pageSize: number) {
  if (!await Enterprise.findByPk(enterpriseId)) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  const result = await Assessment.findAndCountAll({ where: { enterpriseId }, ...pagination(page, pageSize), order: defaultOrder });
  return { data: result.rows, pagination: { page, pageSize, total: result.count } };
}

export async function createAssessment(enterpriseId: number, input: z.output<typeof assessmentSchema>) {
  const sequelize = Enterprise.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  return sequelize.transaction(async transaction => {
    const enterprise = await Enterprise.findByPk(enterpriseId, { transaction, lock: transaction.LOCK.UPDATE });
    if (!enterprise) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    return Assessment.create({ enterpriseId, ...input, status: 'draft' }, { transaction });
  });
}

export async function getAssessment(enterpriseId: number, id: number) {
  const assessment = await Assessment.findOne({ where: { id, enterpriseId } });
  if (!assessment) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  return assessment;
}

export async function removeAssessment(enterpriseId: number, id: number) {
  const sequelize = Assessment.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  await sequelize.transaction(async transaction => {
    const assessment = await Assessment.findOne({ where: { id, enterpriseId }, transaction, lock: transaction.LOCK.UPDATE });
    if (!assessment) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    await assessment.destroy({ transaction });
  });
}
