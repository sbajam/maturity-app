import { Transaction } from 'sequelize';
import { Assessment, DataSource, Enterprise } from '../models/index.js';

export async function dashboardSummary() {
  const sequelize = Enterprise.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  return sequelize.transaction({ isolationLevel: Transaction.ISOLATION_LEVELS.REPEATABLE_READ, readOnly: true }, async transaction => {
    const [enterpriseCount, enabledSourceCount, draftAssessmentCount] = await Promise.all([
      Enterprise.count({ transaction }),
      DataSource.count({ where: { enabled: true }, transaction }),
      Assessment.count({ where: { status: 'draft' }, transaction }),
    ]);
    return { enterpriseCount, enabledSourceCount, draftAssessmentCount, latestResult: null };
  });
}
