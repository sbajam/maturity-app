import type { z } from 'zod';
import { AppError } from '../contracts/errors.js';
import { DataSource, Enterprise, SourceDocument } from '../models/index.js';
import type { dataSourceCreateSchema, dataSourcePatchSchema } from '../schemas/data-source.schema.js';
import { defaultOrder, pagination } from '../utils/pagination.js';

export async function listDataSources(enterpriseId: number, page: number, pageSize: number) {
  if (!await Enterprise.findByPk(enterpriseId)) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  const result = await DataSource.findAndCountAll({ where: { enterpriseId }, ...pagination(page, pageSize), order: defaultOrder });
  return { data: result.rows, pagination: { page, pageSize, total: result.count } };
}

export async function createDataSource(enterpriseId: number, input: z.output<typeof dataSourceCreateSchema>) {
  const sequelize = Enterprise.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  return sequelize.transaction(async transaction => {
    const enterprise = await Enterprise.findByPk(enterpriseId, { transaction, lock: transaction.LOCK.UPDATE });
    if (!enterprise) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    return DataSource.create({ enterpriseId, ...input }, { transaction });
  });
}

export async function updateDataSource(enterpriseId: number, id: number, input: z.output<typeof dataSourcePatchSchema>) {
  const sequelize = DataSource.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  return sequelize.transaction(async transaction => {
    const source = await DataSource.findOne({ where: { id, enterpriseId }, transaction, lock: transaction.LOCK.UPDATE });
    if (!source) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    if (input.businessText != null && source.type !== 'business_document') {
      throw new AppError(400, 'VALIDATION_ERROR', 'Invalid input', [{ path: 'businessText', message: 'Business text requires a business document source' }]);
    }
    return source.update(input, { transaction });
  });
}

export async function removeDataSource(enterpriseId: number, id: number) {
  const sequelize = DataSource.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  await sequelize.transaction(async transaction => {
    const source = await DataSource.findOne({ where: { id, enterpriseId }, transaction, lock: transaction.LOCK.UPDATE });
    if (!source) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    if (await SourceDocument.count({ where: { dataSourceId: id }, transaction })) {
      throw new AppError(409, 'RESOURCE_NOT_EMPTY', 'Resource has dependent records');
    }
    await source.destroy({ transaction });
  });
}
