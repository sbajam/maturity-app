import path from 'node:path';
import { Readable } from 'node:stream';
import { fromBuffer } from 'yauzl';
import { AppError } from '../contracts/errors.js';
import { DataSource, SourceDocument } from '../models/index.js';
import { FileStorage } from '../utils/file-storage.js';
import { defaultOrder, pagination } from '../utils/pagination.js';

async function isDocx(bytes: Buffer): Promise<boolean> {
  return new Promise(resolve => {
    fromBuffer(bytes, { lazyEntries: true, validateEntrySizes: true }, (error, zip) => {
      if (error || !zip) return resolve(false);
      let finished = false; let count = 0;
      const found = new Set<string>();
      const end = (value: boolean) => { if (!finished) { finished = true; zip.close(); resolve(value); } };
      zip.on('error', () => end(false));
      zip.on('end', () => end(found.has('[Content_Types].xml') && found.has('word/document.xml')));
      zip.on('entry', entry => {
        if (++count > 10000 || entry.fileName.startsWith('/') || entry.fileName.split('/').includes('..') || entry.fileName.includes('\\') || (entry.generalPurposeBitFlag & 1)) return end(false);
        if (entry.fileName !== '[Content_Types].xml' && entry.fileName !== 'word/document.xml') return zip.readEntry();
        if (found.has(entry.fileName) || entry.uncompressedSize > 2 * 1024 * 1024) return end(false);
        zip.openReadStream(entry, (streamError, stream) => {
          if (streamError || !stream) return end(false);
          const chunks: Buffer[] = []; let size = 0;
          stream.on('data', (chunk: Buffer) => { size += chunk.length; if (size > 2 * 1024 * 1024) { stream.destroy(); end(false); } else chunks.push(chunk); });
          stream.on('error', () => end(false));
          stream.on('end', () => {
            const xml = Buffer.concat(chunks).toString('utf8');
            const valid = entry.fileName === '[Content_Types].xml' ? xml.includes('application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml') : /<(?:\w+:)?document(?:\s|>)/.test(xml);
            if (!valid) return end(false);
            found.add(entry.fileName); zip.readEntry();
          });
        });
      });
      zip.readEntry();
    });
  });
}

export async function validateFile(file: Express.Multer.File) {
  const originalName = path.posix.basename(file.originalname.replaceAll('\\', '/')).replace(/[\x00-\x1f\x7f]/g, '').trim();
  if (!originalName || originalName.length > 255) throw new AppError(400, 'VALIDATION_ERROR', 'Invalid file name');
  const extension = path.extname(originalName).toLowerCase();
  const bytes = file.buffer;
  const pdf = extension === '.pdf' && file.mimetype === 'application/pdf' && bytes.subarray(0, 5).equals(Buffer.from('%PDF-'));
  const docx = extension === '.docx' && file.mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' && await isDocx(bytes);
  let text = false;
  if (extension === '.txt' && file.mimetype === 'text/plain' && !bytes.includes(0)) {
    try { new TextDecoder('utf-8', { fatal: true }).decode(bytes); text = true; } catch { text = false; }
  }
  if (!pdf && !docx && !text) throw new AppError(415, 'UNSUPPORTED_FILE_TYPE', 'Unsupported file type');
  return { originalName, mediaType: file.mimetype };
}

async function requireSource(enterpriseId: number, sourceId: number) {
  const source = await DataSource.findOne({ where: { id: sourceId, enterpriseId } });
  if (!source || source.type !== 'business_document') throw new AppError(404, 'NOT_FOUND', 'Resource not found');
}

function dto(document: SourceDocument) {
  const { id, dataSourceId, originalName, mediaType, sizeBytes, sha256, createdAt, updatedAt } = document;
  return { id, dataSourceId, originalName, mediaType, sizeBytes, sha256, createdAt, updatedAt };
}

export async function listDocuments(enterpriseId: number, sourceId: number, page: number, pageSize: number) {
  await requireSource(enterpriseId, sourceId);
  const result = await SourceDocument.findAndCountAll({ where: { dataSourceId: sourceId }, ...pagination(page, pageSize), order: defaultOrder });
  return { data: result.rows.map(dto), pagination: { page, pageSize, total: result.count } };
}

export async function uploadDocument(enterpriseId: number, sourceId: number, file: Express.Multer.File, root: string, limit: number) {
  if (!file.buffer.length) throw new AppError(400, 'VALIDATION_ERROR', 'A nonempty file is required');
  if (file.buffer.length > limit) throw new AppError(413, 'FILE_TOO_LARGE', 'File too large');
  const metadata = await validateFile(file);
  await requireSource(enterpriseId, sourceId);
  const storage = new FileStorage(root); const key = storage.newKey();
  const staged = await storage.stage(key, Readable.from([file.buffer]), limit);
  const sequelize = SourceDocument.sequelize;
  if (!sequelize) { await storage.remove(key, 'staging'); throw new Error('Models are not initialized'); }
  let moved = false;
  try {
    const document = await sequelize.transaction(async transaction => {
      const source = await DataSource.findOne({ where: { id: sourceId, enterpriseId }, transaction, lock: transaction.LOCK.UPDATE });
      if (!source || source.type !== 'business_document') throw new AppError(404, 'NOT_FOUND', 'Resource not found');
      await sequelize.query('SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))', { replacements: { key }, transaction });
      await storage.move(key, 'staging', 'objects'); moved = true;
      return SourceDocument.create({ dataSourceId: sourceId, storageKey: key, ...metadata, ...staged }, { transaction });
    });
    return dto(document);
  } catch (error) {
    if (!moved) await storage.remove(key, 'staging').catch(() => undefined);
    throw error;
  }
}

async function ownedDocument(enterpriseId: number, sourceId: number, documentId: number) {
  await requireSource(enterpriseId, sourceId);
  const document = await SourceDocument.findOne({ where: { id: documentId, dataSourceId: sourceId } });
  if (!document) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  return document;
}

export async function downloadDocument(enterpriseId: number, sourceId: number, documentId: number, root: string) {
  const document = await ownedDocument(enterpriseId, sourceId, documentId);
  const file = await new FileStorage(root).openRead(document.storageKey);
  return { document: dto(document), file };
}

export async function removeDocument(enterpriseId: number, sourceId: number, documentId: number, root: string) {
  await requireSource(enterpriseId, sourceId);
  const sequelize = SourceDocument.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  const storage = new FileStorage(root); let key: string | undefined; let moved = false; let callbackCompleted = false;
  try { await sequelize.transaction(async transaction => {
    const document = await SourceDocument.findOne({ where: { id: documentId, dataSourceId: sourceId }, transaction, lock: transaction.LOCK.UPDATE });
    if (!document) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    key = document.storageKey;
    await sequelize.query('SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))', { replacements: { key }, transaction });
    await storage.move(key, 'objects', 'quarantine'); moved = true;
    await document.destroy({ transaction });
    callbackCompleted = true;
  }); } catch (error) {
    if (moved && !callbackCompleted && key) await storage.move(key, 'quarantine', 'objects').catch(() => undefined);
    throw error;
  }
  if (key) await storage.remove(key, 'quarantine').catch(() => undefined);
}
