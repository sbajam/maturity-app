import type { z } from 'zod';
import { AppError } from '../contracts/errors.js';
import { Assessment, DataSource, Enterprise } from '../models/index.js';
import type { enterpriseSchema } from '../schemas/enterprise.schema.js';
import { defaultOrder, pagination } from '../utils/pagination.js';

export async function listEnterprises(page: number, pageSize: number) {
  const result = await Enterprise.findAndCountAll({ ...pagination(page, pageSize), order: defaultOrder });
  return { data: result.rows, pagination: { page, pageSize, total: result.count } };
}

export async function createEnterprise(input: z.output<typeof enterpriseSchema>) {
  return Enterprise.create(input);
}

export async function getEnterprise(id: number) {
  const enterprise = await Enterprise.findByPk(id);
  if (!enterprise) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
  return enterprise;
}

export async function removeEnterprise(id: number) {
  const sequelize = Enterprise.sequelize;
  if (!sequelize) throw new Error('Models are not initialized');
  await sequelize.transaction(async transaction => {
    const enterprise = await Enterprise.findByPk(id, { transaction, lock: transaction.LOCK.UPDATE });
    if (!enterprise) throw new AppError(404, 'NOT_FOUND', 'Resource not found');
    const [sources, assessments] = await Promise.all([
      DataSource.count({ where: { enterpriseId: id }, transaction }),
      Assessment.count({ where: { enterpriseId: id }, transaction }),
    ]);
    if (sources || assessments) throw new AppError(409, 'RESOURCE_NOT_EMPTY', 'Resource has dependent records');
    await enterprise.destroy({ transaction });
  });
}
