import path from 'node:path';
import { realpath } from 'node:fs/promises';
import type { AppEnv } from '../config/env.js';

export async function assertDemoIsolation(env: AppEnv, realUrl?: string, realRoot?: string): Promise<void> {
  if (env.APP_MODE !== 'demo' || !realUrl || !realRoot) throw new Error('Demo isolation settings are required');
  const demo = new URL(env.DATABASE_URL); const real = new URL(realUrl);
  const demoRoot = await realpath(path.resolve(env.UPLOAD_ROOT)); const productionRoot = await realpath(path.resolve(realRoot));
  const rootOverlap = (a: string, b: string) => {
    const relative = path.relative(a, b);
    return relative === '' || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
  };
  if (!decodeURIComponent(demo.pathname).endsWith('_demo') || decodeURIComponent(demo.pathname) === decodeURIComponent(real.pathname) || rootOverlap(demoRoot, productionRoot) || rootOverlap(productionRoot, demoRoot)) throw new Error('Demo storage and database must be separate');
}
