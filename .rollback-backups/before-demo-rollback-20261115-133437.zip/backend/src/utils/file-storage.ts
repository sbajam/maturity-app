import { createHash, randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, open, rename, unlink } from 'node:fs/promises';
import path from 'node:path';
import { AppError } from '../contracts/errors.js';

type Area = 'staging' | 'objects' | 'quarantine';
const keyPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

export class FileStorage {
  constructor(private readonly root: string) {}

  newKey(): string { return randomUUID(); }

  private location(area: Area, key: string): string {
    if (!keyPattern.test(key)) throw new AppError(400, 'VALIDATION_ERROR', 'Invalid storage key');
    return path.join(path.resolve(this.root), area, key);
  }

  async prepare(): Promise<void> {
    for (const area of ['staging', 'objects', 'quarantine'] as const) {
      await mkdir(path.join(path.resolve(this.root), area), { recursive: true, mode: 0o700 });
    }
  }

  async stage(key: string, contents: AsyncIterable<Buffer>, limit: number): Promise<{ sizeBytes: number; sha256: string }> {
    await this.prepare();
    const target = this.location('staging', key);
    const file = await open(target, 'wx', 0o600);
    const hash = createHash('sha256');
    let sizeBytes = 0;
    try {
      for await (const chunk of contents) {
        sizeBytes += chunk.length;
        if (sizeBytes > limit) throw new AppError(413, 'FILE_TOO_LARGE', 'File too large');
        hash.update(chunk);
        let offset = 0;
        while (offset < chunk.length) {
          const result = await file.write(chunk, offset, chunk.length - offset);
          if (!result.bytesWritten) throw new Error('File write failed');
          offset += result.bytesWritten;
        }
      }
      if (!sizeBytes) throw new AppError(400, 'VALIDATION_ERROR', 'Empty file');
      await file.close();
      return { sizeBytes, sha256: hash.digest('hex') };
    } catch (error) {
      await file.close().catch(() => undefined);
      await unlink(target).catch(() => undefined);
      throw error;
    }
  }

  async move(key: string, from: Area, to: Area): Promise<void> {
    await rename(this.location(from, key), this.location(to, key));
  }

  async remove(key: string, area: Area): Promise<void> { await unlink(this.location(area, key)); }
  async openRead(key: string) { return open(this.location('objects', key), 'r'); }
  read(key: string) { return createReadStream(this.location('objects', key)); }
}
