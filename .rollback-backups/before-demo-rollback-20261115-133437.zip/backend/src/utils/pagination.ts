export function pagination(page: number, pageSize: number): { limit: number; offset: number } {
  return { limit: pageSize, offset: (page - 1) * pageSize };
}

export const defaultOrder: [string, 'DESC'][] = [['createdAt', 'DESC'], ['id', 'DESC']];
