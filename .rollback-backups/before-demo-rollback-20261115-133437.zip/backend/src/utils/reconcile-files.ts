import { readdir, stat, unlink } from 'node:fs/promises';
import path from 'node:path';
import { FileStorage } from './file-storage.js';

export async function reconcileFiles(root: string, keys: Set<string>, graceMs = 86400000): Promise<string[]> {
  const storage = new FileStorage(root); const messages: string[] = [];
  await storage.prepare();
  const areas = ['staging', 'objects', 'quarantine'] as const;
  const [staging, objects, quarantine] = (await Promise.all(areas.map(area => readdir(path.join(root, area))))).map(names => new Set(names));
  const all = new Set([...keys, ...staging, ...objects, ...quarantine]);
  const valid = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
  for (const key of all) {
    if (!valid.test(key)) { messages.push('Unrecognized file; left untouched'); continue; }
    const inDb = keys.has(key); const object = objects.has(key); const isolated = quarantine.has(key); const staged = staging.has(key);
    if (Number(object) + Number(isolated) + Number(staged) > 1) { messages.push(`Ambiguous copies: ${key}`); continue; }
    if (inDb && isolated) { await storage.move(key, 'quarantine', 'objects'); messages.push(`Restored: ${key}`); continue; }
    if (inDb && !object) { messages.push(`Missing object: ${key}`); continue; }
    if (!inDb && isolated) { await storage.remove(key, 'quarantine'); messages.push(`Removed quarantine: ${key}`); continue; }
    const area = !inDb && object ? 'objects' : !inDb && staged ? 'staging' : null;
    if (area) {
      const filename = path.join(root, area, key); const info = await stat(filename);
      if (info.isFile() && Date.now() - info.mtimeMs >= graceMs) { await unlink(filename); messages.push(`Removed orphan: ${key}`); }
    }
  }
  return messages;
}
