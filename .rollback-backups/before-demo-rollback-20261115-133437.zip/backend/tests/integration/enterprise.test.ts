import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/app.js';
import { parseEnv } from '../../src/config/env.js';
import { createDatabase } from '../../src/config/database.js';
import { initModels } from '../../src/models/index.js';

describe('enterprise API with a migrated test database', () => {
  const env = parseEnv(process.env);
  const database = createDatabase(env);
  const app = createApp(env);
  beforeAll(() => { if (env.NODE_ENV !== 'test' || !new URL(env.DATABASE_URL).pathname.endsWith('_test')) throw new Error('A dedicated test database is required'); initModels(database); });
  afterAll(async () => { await database.close(); });
  it('creates, reads and deletes an enterprise', async () => {
    const created = await request(app).post('/api/v1/enterprises').send({ name: 'Integration', industry: 'Test' }).expect(201);
    const id: number = created.body.data.id;
    await request(app).get(`/api/v1/enterprises/${id}`).expect(200);
    await request(app).delete(`/api/v1/enterprises/${id}`).expect(204);
  });
});
