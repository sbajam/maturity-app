import 'dotenv/config';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { randomUUID, createHash } from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';
import request from 'supertest';
import { QueryTypes, Sequelize } from 'sequelize';
import { createApp } from '../../src/app.js';
import { parseEnv } from '../../src/config/env.js';
import { createDatabase } from '../../src/config/database.js';
import { initModels, Enterprise, DataSource, Assessment, SourceDocument } from '../../src/models/index.js';
import { FileStorage } from '../../src/utils/file-storage.js';
import { reconcileFiles } from '../../src/utils/reconcile-files.js';

const marker = `runtime-${randomUUID()}`;
let db: Sequelize; let app: ReturnType<typeof createApp>; let root: string;
let enterprise = 0; let other = 0; let source = 0; let assessment = 0;
const documents: number[] = [];

function docx(): Buffer {
  const entries: Record<string, string> = {
    '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
    '_rels/.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
    'word/document.xml': '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body/></w:document>',
  };
  const local: Buffer[] = []; const directory: Buffer[] = []; let offset = 0;
  for (const [name, value] of Object.entries(entries)) {
    const n = Buffer.from(name); const b = Buffer.from(value); let crc = 0xffffffff;
    for (const byte of b) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1)); }
    crc = (crc ^ 0xffffffff) >>> 0;
    const l = Buffer.alloc(30); l.writeUInt32LE(0x04034b50); l.writeUInt16LE(20, 4); l.writeUInt32LE(crc, 14); l.writeUInt32LE(b.length, 18); l.writeUInt32LE(b.length, 22); l.writeUInt16LE(n.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt32LE(crc, 16); c.writeUInt32LE(b.length, 20); c.writeUInt32LE(b.length, 24); c.writeUInt16LE(n.length, 28); c.writeUInt32LE(offset, 42);
    local.push(l, n, b); directory.push(c, n); offset += l.length + n.length + b.length;
  }
  const central = Buffer.concat(directory); const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50); end.writeUInt16LE(3, 8); end.writeUInt16LE(3, 10); end.writeUInt32LE(central.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, central, end]);
}

function pdf(): Buffer {
  let text = '%PDF-1.4\n'; const offsets = [0];
  for (const object of ['<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>', '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 72 72] /Resources << >> >>']) {
    offsets.push(Buffer.byteLength(text)); text += `${offsets.length - 1} 0 obj\n${object}\nendobj\n`;
  }
  const xref = Buffer.byteLength(text); text += `xref\n0 4\n0000000000 65535 f \n${offsets.slice(1).map(value => `${String(value).padStart(10, '0')} 00000 n \n`).join('')}trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(text);
}

describe('development database API workflow', () => {
  beforeAll(async () => {
    const parsed = parseEnv(process.env); const url = new URL(parsed.DATABASE_URL);
    if (url.hostname !== '127.0.0.1' || (url.port || '5432') !== '5432' || url.pathname !== '/maturity_app_dev' || decodeURIComponent(url.username) !== 'maturity_user') throw new Error('Unexpected database target');
    db = createDatabase(parsed);
    const rows = await db.query<{ db: string }>('SELECT current_database() AS db', { type: QueryTypes.SELECT });
    if (rows[0]?.db !== 'maturity_app_dev') throw new Error('Unexpected connected database');
    root = await mkdtemp(path.join(tmpdir(), 'maturity-integration-'));
    initModels(db); app = createApp({ ...parsed, NODE_ENV: 'test', UPLOAD_ROOT: root });
  });
  afterAll(async () => {
    let canRemoveRoot = true;
    if (app) {
      for (const id of documents) await request(app).delete(`/api/v1/enterprises/${enterprise}/data-sources/${source}/documents/${id}`);
      if (assessment) await request(app).delete(`/api/v1/enterprises/${enterprise}/assessments/${assessment}`);
      if (source) await request(app).delete(`/api/v1/enterprises/${enterprise}/data-sources/${source}`);
      if (enterprise) await request(app).delete(`/api/v1/enterprises/${enterprise}`);
      if (other) await request(app).delete(`/api/v1/enterprises/${other}`);
      if (source && await SourceDocument.count({ where: { dataSourceId: source } })) canRemoveRoot = false;
    }
    if (db) await db.close();
    if (root && canRemoveRoot) await rm(root, { recursive: true, force: true });
  });
  it('checks all 17 API operations and their persisted changes', async () => {
    const before = await request(app).get('/api/v1/dashboard').expect(200);
    const first = await request(app).post('/api/v1/enterprises').send({ name: marker, industry: 'Test' }).expect(201);
    enterprise = first.body.data.id;
    other = (await request(app).post('/api/v1/enterprises').send({ name: `${marker}-other`, industry: 'Test' }).expect(201)).body.data.id;
    expect((await Enterprise.findByPk(enterprise))?.name).toBe(marker);
    await request(app).get('/api/v1/enterprises?page=1&pageSize=100').expect(200);
    const page = await request(app).get('/api/v1/enterprises?page=1&pageSize=1').expect(200);
    expect(page.body.pagination).toMatchObject({ page: 1, pageSize: 1, total: 2 });
    expect(page.body.data[0].id).toBe(other);
    await request(app).get('/api/v1/enterprises?pageSize=101').expect(400);
    await request(app).get(`/api/v1/enterprises/${enterprise}`).expect(200);
    await request(app).get('/api/v1/enterprises/-1').expect(400);
    await request(app).post('/api/v1/enterprises').send({ name: '', industry: 'Test' }).expect(400);
    const sourcePath = `/api/v1/enterprises/${enterprise}/data-sources`;
    source = (await request(app).post(sourcePath).send({ name: marker, type: 'business_document' }).expect(201)).body.data.id;
    await request(app).get(sourcePath).expect(200);
    await request(app).patch(`${sourcePath}/${source}`).send({ enabled: false }).expect(200);
    expect((await DataSource.findByPk(source))?.enabled).toBe(false);
    await request(app).patch(`${sourcePath}/${source}`).send({ enabled: true }).expect(200);
    await request(app).patch(`/api/v1/enterprises/${other}/data-sources/${source}`).send({ enabled: false }).expect(404);
    await request(app).delete(`/api/v1/enterprises/${enterprise}`).expect(409);
    const assessments = `/api/v1/enterprises/${enterprise}/assessments`;
    assessment = (await request(app).post(assessments).send({ name: marker }).expect(201)).body.data.id;
    expect((await Assessment.findByPk(assessment))?.status).toBe('draft');
    await request(app).post(assessments).send({ name: marker, status: 'completed' }).expect(400);
    await request(app).get(assessments).expect(200);
    await request(app).get(`${assessments}/${assessment}`).expect(200);
    await request(app).get(`/api/v1/enterprises/${other}/assessments/${assessment}`).expect(404);
    const docPath = `${sourcePath}/${source}/documents`; const bytes = Buffer.from('runtime test text');
    const uploaded = await request(app).post(docPath).attach('file', bytes, { filename: 'runtime.txt', contentType: 'text/plain' }).expect(201);
    documents.push(uploaded.body.data.id);
    expect(uploaded.body.data.sha256).toBe(createHash('sha256').update(bytes).digest('hex'));
    expect(uploaded.body.data).not.toHaveProperty('storageKey');
    expect(await SourceDocument.count({ where: { dataSourceId: source } })).toBe(1);
    await request(app).get(docPath).expect(200);
    const downloaded = await request(app).get(`${docPath}/${documents[0]}/content`).expect(200);
    expect(downloaded.text).toBe(bytes.toString()); expect(downloaded.headers['x-content-type-options']).toBe('nosniff');
    for (const item of [{ name: 'runtime.pdf', type: 'application/pdf', data: pdf() }, { name: 'runtime.docx', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', data: docx() }]) {
      const result = await request(app).post(docPath).attach('file', item.data, { filename: item.name, contentType: item.type }).expect(201);
      const id: number = result.body.data.id; documents.push(id);
      expect(result.body.data.sha256).toBe(createHash('sha256').update(item.data).digest('hex'));
      const file = await request(app).get(`${docPath}/${id}/content`).buffer(true).parse((response, callback) => {
        const chunks: Buffer[] = [];
        response.on('data', (chunk: Buffer) => chunks.push(chunk));
        response.on('end', () => callback(null, Buffer.concat(chunks)));
      }).expect(200);
      expect(Buffer.from(file.body)).toEqual(item.data);
    }
    await request(app).post(docPath).attach('file', Buffer.from('fake'), { filename: 'fake.pdf', contentType: 'application/pdf' }).expect(415);
    expect(await SourceDocument.count({ where: { dataSourceId: source } })).toBe(3);
    await request(app).post(docPath).attach('file', Buffer.alloc(0), { filename: 'empty.txt', contentType: 'text/plain' }).expect(400);
    await request(app).post(docPath).attach('file', Buffer.alloc(20971521, 65), { filename: 'large.txt', contentType: 'text/plain' }).expect(413);
    const concurrent = await Promise.all(['one', 'two'].map(value => request(app).post(docPath).attach('file', Buffer.from(value), { filename: `${value}.txt`, contentType: 'text/plain' })));
    for (const result of concurrent) { expect(result.status).toBe(201); documents.push(result.body.data.id); }
    expect(await SourceDocument.count({ where: { dataSourceId: source } })).toBe(5);
    const record = await SourceDocument.findByPk(documents[0]);
    if (!record) throw new Error('Test document missing');
    const storage = new FileStorage(root);
    await storage.move(record.storageKey, 'objects', 'quarantine');
    const records = await SourceDocument.findAll({ where: { dataSourceId: source }, attributes: ['storageKey'] });
    const keys = new Set(records.map(item => item.storageKey));
    await reconcileFiles(root, keys); await reconcileFiles(root, keys);
    expect((await request(app).get(`${docPath}/${documents[0]}/content`).expect(200)).text).toBe(bytes.toString());
    const failedDestroy = vi.spyOn(SourceDocument.prototype, 'destroy').mockRejectedValueOnce(new Error('simulated write failure'));
    try {
      await request(app).delete(`${docPath}/${documents[0]}`).expect(500);
      expect(await SourceDocument.findByPk(documents[0])).not.toBeNull();
      expect((await request(app).get(`${docPath}/${documents[0]}/content`).expect(200)).text).toBe(bytes.toString());
    } finally { failedDestroy.mockRestore(); }
    await request(app).get(`/api/v1/enterprises/${other}/data-sources/${source}/documents/${documents[0]}/content`).expect(404);
    const invalidRoot = path.join(root, 'not-a-directory'); await writeFile(invalidRoot, 'x');
    const unavailable = createApp({ ...parseEnv(process.env), NODE_ENV: 'test', UPLOAD_ROOT: invalidRoot });
    await request(unavailable).post(docPath).attach('file', bytes, { filename: 'blocked.txt', contentType: 'text/plain' }).expect(503);
    await request(app).delete(`${sourcePath}/${source}`).expect(409);
    const dashboard = await request(app).get('/api/v1/dashboard').expect(200);
    expect(dashboard.body.data.enterpriseCount).toBe(before.body.data.enterpriseCount + 2);
    expect(dashboard.body.data.enabledSourceCount).toBe(before.body.data.enabledSourceCount + 1);
    expect(dashboard.body.data.draftAssessmentCount).toBe(before.body.data.draftAssessmentCount + 1);
    expect(dashboard.body.data.latestResult).toBeNull();
    for (const id of documents) await request(app).delete(`${docPath}/${id}`).expect(204); documents.length = 0;
    expect(await SourceDocument.count({ where: { dataSourceId: source } })).toBe(0);
    await request(app).delete(`${assessments}/${assessment}`).expect(204); assessment = 0;
    await request(app).delete(`${sourcePath}/${source}`).expect(204); source = 0;
    await request(app).delete(`/api/v1/enterprises/${enterprise}`).expect(204); enterprise = 0;
    await request(app).delete(`/api/v1/enterprises/${other}`).expect(204); other = 0;
  }, 30000);
});
