import { afterAll, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/app.js';
import { parseEnv } from '../../src/config/env.js';
import { createDatabase } from '../../src/config/database.js';
import { initModels } from '../../src/models/index.js';

const env = parseEnv({ NODE_ENV: 'test', DATABASE_URL: 'postgres://placeholder:placeholder@127.0.0.1:1/unavailable_test', CORS_ORIGIN: 'http://localhost:3000', UPLOAD_ROOT: './unused' });
const db = createDatabase(env);
initModels(db);
afterAll(async () => { await db.close(); });
describe('database unavailable', () => {
  it('returns a sanitized 503', async () => {
    const response = await request(createApp(env)).get('/api/v1/dashboard');
    expect(response.status).toBe(503);
    expect(response.body).toEqual({ error: { code: 'SERVICE_UNAVAILABLE', message: 'Service unavailable' } });
  });
});
