import { describe, expect, it, vi } from 'vitest';
import { assessmentSchema } from '../../src/schemas/assessment.schema.js';
import { Assessment } from '../../src/models/index.js';
import { getAssessment } from '../../src/services/assessment.service.js';

describe('draft assessments', () => {
  it('defaults version and rejects status and scores', () => {
    expect(assessmentSchema.parse({ name: ' Draft ' })).toEqual({ name: 'Draft', description: null, version: '1.0' });
    expect(assessmentSchema.safeParse({ name: 'Draft', status: 'completed' }).success).toBe(false);
    expect(assessmentSchema.safeParse({ name: 'Draft', score: 5 }).success).toBe(false);
  });
  it('queries by both enterprise and assessment and returns 404 when not found', async () => {
    const find = vi.spyOn(Assessment, 'findOne').mockResolvedValueOnce(null);
    await expect(getAssessment(2, 3)).rejects.toMatchObject({ status: 404, code: 'NOT_FOUND' });
    expect(find).toHaveBeenCalledWith({ where: { id: 3, enterpriseId: 2 } });
    find.mockRestore();
  });
});
