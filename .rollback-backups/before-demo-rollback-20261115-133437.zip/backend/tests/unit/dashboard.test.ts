import { beforeEach, describe, expect, it, vi } from 'vitest';

const models = vi.hoisted(() => ({
  enterpriseCount: vi.fn(),
  sourceCount: vi.fn(),
  assessmentCount: vi.fn(),
  transaction: vi.fn(),
}));
vi.mock('../../src/models/index.js', () => ({
  Enterprise: { count: models.enterpriseCount, sequelize: { transaction: models.transaction } },
  DataSource: { count: models.sourceCount },
  Assessment: { count: models.assessmentCount },
}));
import { dashboardSummary } from '../../src/services/dashboard.service.js';

describe('dashboard summary', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    models.transaction.mockImplementation(async (_options, callback) => callback({}));
  });
  it.each([[0, 0, 0], [3, 4, 2]])('returns global counts %i, %i, %i', async (enterprises, sources, assessments) => {
    models.enterpriseCount.mockResolvedValue(enterprises);
    models.sourceCount.mockResolvedValue(sources);
    models.assessmentCount.mockResolvedValue(assessments);
    await expect(dashboardSummary()).resolves.toEqual({ enterpriseCount: enterprises, enabledSourceCount: sources, draftAssessmentCount: assessments, latestResult: null });
    expect(models.enterpriseCount).toHaveBeenCalledWith({ transaction: {} });
    expect(models.sourceCount).toHaveBeenCalledWith({ where: { enabled: true }, transaction: {} });
    expect(models.assessmentCount).toHaveBeenCalledWith({ where: { status: 'draft' }, transaction: {} });
  });
});
