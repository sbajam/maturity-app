import { mkdtemp, mkdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { parseEnv } from '../../src/config/env.js';
import { assertDemoIsolation } from '../../src/utils/demo-guard.js';

let root: string; let demoRoot: string; let realRoot: string;
beforeAll(async () => { root = await mkdtemp(path.join(tmpdir(), 'maturity-demo-')); demoRoot = path.join(root, 'demo'); realRoot = path.join(root, 'real'); await mkdir(demoRoot); await mkdir(realRoot); await mkdir(path.join(demoRoot, 'child')); });
afterAll(async () => { await rm(root, { recursive: true, force: true }); });
const env = () => parseEnv({ APP_MODE: 'demo', DATABASE_URL: 'postgres://test:test@localhost/app_demo', CORS_ORIGIN: 'http://localhost:3000', UPLOAD_ROOT: demoRoot });
describe('demo isolation', () => {
  it('accepts separately configured demo resources', async () => { await expect(assertDemoIsolation(env(), 'postgres://test:test@localhost/app', realRoot)).resolves.toBeUndefined(); });
  it('fails closed for real mode, missing settings, the real DB and overlapping roots', async () => {
    await expect(assertDemoIsolation({ ...env(), APP_MODE: 'real' }, 'postgres://test:test@localhost/app', realRoot)).rejects.toThrow();
    await expect(assertDemoIsolation(env())).rejects.toThrow();
    await expect(assertDemoIsolation(env(), 'postgres://test:test@other-host/app_demo', realRoot)).rejects.toThrow();
    await expect(assertDemoIsolation(env(), 'postgres://test:test@localhost/app', path.join(demoRoot, 'child'))).rejects.toThrow();
    await expect(assertDemoIsolation({ ...env(), DATABASE_URL: 'postgres://test:test@localhost/app' }, 'postgres://test:test@localhost/app', realRoot)).rejects.toThrow();
  });
});
