import { describe, expect, it } from 'vitest';
import { validateFile } from '../../src/services/document.service.js';

function file(originalname: string, mimetype: string, data: string): Express.Multer.File {
  const buffer = Buffer.from(data);
  return { fieldname: 'file', originalname, encoding: '7bit', mimetype, size: buffer.length, buffer, stream: null as never, destination: '', filename: '', path: '' };
}

function zip(entries: Record<string, string>): Buffer {
  const local: Buffer[] = []; const central: Buffer[] = []; let offset = 0;
  for (const [name, content] of Object.entries(entries)) {
    const n = Buffer.from(name); const data = Buffer.from(content);
    let crc = 0xffffffff;
    for (const byte of data) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1)); }
    crc = (crc ^ 0xffffffff) >>> 0;
    const l = Buffer.alloc(30); l.writeUInt32LE(0x04034b50); l.writeUInt16LE(20, 4); l.writeUInt32LE(crc, 14); l.writeUInt32LE(data.length, 18); l.writeUInt32LE(data.length, 22); l.writeUInt16LE(n.length, 26);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt32LE(crc, 16); c.writeUInt32LE(data.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(n.length, 28); c.writeUInt32LE(offset, 42);
    local.push(l, n, data); central.push(c, n); offset += l.length + n.length + data.length;
  }
  const directory = Buffer.concat(central); const e = Buffer.alloc(22);
  e.writeUInt32LE(0x06054b50); e.writeUInt16LE(Object.keys(entries).length, 8); e.writeUInt16LE(Object.keys(entries).length, 10); e.writeUInt32LE(directory.length, 12); e.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, directory, e]);
}

describe('document content checks', () => {
  it('accepts PDF and UTF-8 text and removes path components', async () => {
    await expect(validateFile(file('../report.pdf', 'application/pdf', '%PDF-1.7'))).resolves.toEqual({ originalName: 'report.pdf', mediaType: 'application/pdf' });
    expect((await validateFile(file('text.txt', 'text/plain', 'hello'))).mediaType).toBe('text/plain');
  });
  it('rejects mismatched content', async () => {
    await expect(validateFile(file('report.pdf', 'application/pdf', 'not pdf'))).rejects.toThrow();
    await expect(validateFile(file('test.txt', 'text/plain', 'a\0b'))).rejects.toThrow();
    await expect(validateFile(file('fake.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'PK\x03\x04[Content_Types].xmlword/PK\x05\x06'))).rejects.toThrow();
  });
  it('accepts a DOCX archive with required entries and rejects malformed structure', async () => {
    const doc = file('test.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '');
    doc.buffer = zip({ '[Content_Types].xml': '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>', '_rels/.rels': '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>', 'word/document.xml': '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body/></w:document>' });
    await expect(validateFile(doc)).resolves.toMatchObject({ originalName: 'test.docx' });
    doc.buffer = zip({ '[Content_Types].xml': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml', 'word/document.xml': 'not xml' });
    await expect(validateFile(doc)).rejects.toThrow();
  });
});
