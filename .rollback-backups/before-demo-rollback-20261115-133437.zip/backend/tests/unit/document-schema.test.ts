import { describe, expect, it } from 'vitest';
import { documentItemParamsSchema, documentParentParamsSchema } from '../../src/schemas/document.schema.js';

describe('document route identifiers', () => {
  it('validates all parent and document IDs', () => {
    expect(documentItemParamsSchema.parse({ enterpriseId: '1', sourceId: '2', documentId: '3' })).toEqual({ enterpriseId: 1, sourceId: 2, documentId: 3 });
    expect(documentParentParamsSchema.safeParse({ enterpriseId: '1', sourceId: '-2' }).success).toBe(false);
    expect(documentItemParamsSchema.safeParse({ enterpriseId: '1', sourceId: '2', documentId: '0' }).success).toBe(false);
  });
});
