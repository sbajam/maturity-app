import { mkdtemp, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Readable } from 'node:stream';
import { FileStorage } from '../../src/utils/file-storage.js';

const mocks = vi.hoisted(() => ({ transaction: vi.fn(), query: vi.fn(), source: vi.fn(), create: vi.fn(), find: vi.fn(), destroy: vi.fn() }));
vi.mock('../../src/models/index.js', () => ({
  DataSource: { findOne: mocks.source },
  SourceDocument: { sequelize: { transaction: mocks.transaction, query: mocks.query }, create: mocks.create, findOne: mocks.find },
}));
import { downloadDocument, removeDocument, uploadDocument } from '../../src/services/document.service.js';

let root: string;
const tx = { LOCK: { UPDATE: 'UPDATE' } };
const file: Express.Multer.File = { fieldname: 'file', originalname: 'note.txt', encoding: '7bit', mimetype: 'text/plain', size: 4, buffer: Buffer.from('text'), stream: null as never, destination: '', filename: '', path: '' };
async function setupObject() {
  const storage = new FileStorage(root); const key = storage.newKey();
  await storage.stage(key, Readable.from([Buffer.from('test')]), 10);
  await storage.move(key, 'staging', 'objects');
  mocks.find.mockResolvedValue({ storageKey: key, destroy: mocks.destroy });
  return key;
}
beforeEach(async () => {
  root = await mkdtemp(path.join(tmpdir(), 'maturity-doc-'));
  vi.clearAllMocks(); mocks.source.mockResolvedValue({ type: 'business_document' }); mocks.query.mockResolvedValue([]);
  mocks.transaction.mockImplementation(async callback => callback(tx));
});
afterEach(async () => { vi.restoreAllMocks(); await rm(root, { recursive: true, force: true }); });

describe('document service recovery', () => {
  it('stores metadata and hides the internal key on successful upload', async () => {
    mocks.create.mockImplementation(async metadata => ({ id: 1, ...metadata, createdAt: new Date(), updatedAt: new Date() }));
    const result = await uploadDocument(1, 2, file, root, 100);
    expect(result).toMatchObject({ id: 1, dataSourceId: 2, originalName: 'note.txt', sizeBytes: 4 });
    expect(result).not.toHaveProperty('storageKey');
    expect(await readdir(path.join(root, 'objects'))).toHaveLength(1);
  });
  it('keeps an object on metadata failure for later reconciliation', async () => {
    mocks.create.mockRejectedValue(new Error('metadata failure'));
    await expect(uploadDocument(1, 2, file, root, 100)).rejects.toThrow('metadata failure');
    expect(await readdir(path.join(root, 'objects'))).toHaveLength(1);
    expect(await readdir(path.join(root, 'staging'))).toHaveLength(0);
  });
  it('keeps the uploaded object if commit outcome is unknown', async () => {
    mocks.create.mockResolvedValue({ id: 1, dataSourceId: 2, originalName: 'note.txt', mediaType: 'text/plain', sizeBytes: 4, sha256: 'hash', createdAt: new Date(), updatedAt: new Date() });
    mocks.transaction.mockImplementation(async callback => { await callback(tx); throw new Error('commit uncertain'); });
    await expect(uploadDocument(1, 2, file, root, 100)).rejects.toThrow('commit uncertain');
    expect(await readdir(path.join(root, 'objects'))).toHaveLength(1);
  });
  it('cleans staging after a failed move', async () => {
    vi.spyOn(FileStorage.prototype, 'move').mockRejectedValueOnce(new Error('rename failed'));
    await expect(uploadDocument(1, 2, file, root, 100)).rejects.toThrow('rename failed');
    expect(await readdir(path.join(root, 'staging'))).toHaveLength(0);
    expect(await readdir(path.join(root, 'objects'))).toHaveLength(0);
  });
  it('restores quarantine after a definite rollback', async () => {
    const key = await setupObject(); mocks.destroy.mockRejectedValue(new Error('delete failed'));
    await expect(removeDocument(1, 2, 3, root)).rejects.toThrow('delete failed');
    expect(await readdir(path.join(root, 'objects'))).toContain(key);
    expect(await readdir(path.join(root, 'quarantine'))).toHaveLength(0);
  });
  it('keeps quarantine when commit outcome is unknown', async () => {
    const key = await setupObject(); mocks.destroy.mockResolvedValue(undefined);
    mocks.transaction.mockImplementation(async callback => { await callback(tx); throw new Error('commit uncertain'); });
    await expect(removeDocument(1, 2, 3, root)).rejects.toThrow('commit uncertain');
    expect(await readdir(path.join(root, 'quarantine'))).toContain(key);
  });
  it('removes the quarantined file after commit', async () => {
    await setupObject(); mocks.destroy.mockResolvedValue(undefined);
    await removeDocument(1, 2, 3, root);
    expect(await readdir(path.join(root, 'objects'))).toHaveLength(0);
    expect(await readdir(path.join(root, 'quarantine'))).toHaveLength(0);
  });
  it('retains quarantine for reconciliation if post-commit cleanup fails', async () => {
    const key = await setupObject(); mocks.destroy.mockResolvedValue(undefined);
    vi.spyOn(FileStorage.prototype, 'remove').mockRejectedValueOnce(new Error('unlink failed'));
    await removeDocument(1, 2, 3, root);
    expect(await readdir(path.join(root, 'quarantine'))).toContain(key);
  });
  it('rejects access to a document outside the parent source', async () => {
    mocks.find.mockResolvedValue(null);
    await expect(downloadDocument(1, 2, 3, root)).rejects.toMatchObject({ status: 404 });
    expect(mocks.find).toHaveBeenCalledWith({ where: { id: 3, dataSourceId: 2 } });
  });
  it('rejects access when the source does not belong to the enterprise', async () => {
    mocks.source.mockResolvedValue(null);
    await expect(downloadDocument(1, 2, 3, root)).rejects.toMatchObject({ status: 404 });
    expect(mocks.source).toHaveBeenCalledWith({ where: { id: 2, enterpriseId: 1 } });
    expect(mocks.find).not.toHaveBeenCalled();
  });
  it('preserves the object if quarantine move fails', async () => {
    const key = await setupObject(); vi.spyOn(FileStorage.prototype, 'move').mockRejectedValueOnce(new Error('rename failed'));
    await expect(removeDocument(1, 2, 3, root)).rejects.toThrow('rename failed');
    expect(await readdir(path.join(root, 'objects'))).toContain(key);
    expect(mocks.destroy).not.toHaveBeenCalled();
  });
});
