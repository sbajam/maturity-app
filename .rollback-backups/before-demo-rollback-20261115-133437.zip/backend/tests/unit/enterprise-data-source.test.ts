import { describe, expect, it, vi } from 'vitest';
import { enterpriseSchema } from '../../src/schemas/enterprise.schema.js';
import { dataSourceCreateSchema, dataSourcePatchSchema } from '../../src/schemas/data-source.schema.js';
import { Enterprise } from '../../src/models/index.js';
import { listDataSources } from '../../src/services/data-source.service.js';

describe('enterprise and data source rules', () => {
  it('normalizes enterprise text and rejects unrecognized fields', () => {
    expect(enterpriseSchema.parse({ name: ' Example ', industry: ' IT ', country: '  ' })).toMatchObject({ name: 'Example', industry: 'IT', country: null });
    expect(enterpriseSchema.safeParse({ name: 'Example', industry: 'IT', extra: true }).success).toBe(false);
  });
  it('limits business text and prevents source name or type changes', () => {
    expect(dataSourceCreateSchema.safeParse({ name: 'Source', type: 'matomo', businessText: 'text' }).success).toBe(false);
    expect(dataSourceCreateSchema.parse({ name: 'Source', type: 'business_document', businessText: 'text' }).enabled).toBe(true);
    expect(dataSourcePatchSchema.safeParse({ name: 'New name' }).success).toBe(false);
    expect(dataSourcePatchSchema.safeParse({ type: 'custom' }).success).toBe(false);
    expect(dataSourcePatchSchema.safeParse({}).success).toBe(false);
  });
  it('returns not found for a missing enterprise before listing sources', async () => {
    const find = vi.spyOn(Enterprise, 'findByPk').mockResolvedValueOnce(null);
    await expect(listDataSources(5, 1, 20)).rejects.toMatchObject({ status: 404, code: 'NOT_FOUND' });
    find.mockRestore();
  });
});
