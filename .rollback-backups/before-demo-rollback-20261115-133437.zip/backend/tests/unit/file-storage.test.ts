import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import { afterEach, describe, expect, it } from 'vitest';
import { FileStorage } from '../../src/utils/file-storage.js';

const roots: string[] = [];
afterEach(async () => { await Promise.all(roots.splice(0).map(root => rm(root, { recursive: true, force: true }))); });
describe('private file storage', () => {
  it('stages and hashes a file, then moves it to objects', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'maturity-')); roots.push(root);
    const storage = new FileStorage(root); const key = storage.newKey();
    const info = await storage.stage(key, Readable.from([Buffer.from('abc')]), 10);
    expect(info).toEqual({ sizeBytes: 3, sha256: 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad' });
    await storage.move(key, 'staging', 'objects');
    expect(await readFile(path.join(root, 'objects', key), 'utf8')).toBe('abc');
  });
  it('rejects traversal, empty files and oversized files', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'maturity-')); roots.push(root);
    const storage = new FileStorage(root);
    await expect(storage.stage('../escape', Readable.from([Buffer.from('x')]), 10)).rejects.toMatchObject({ status: 400 });
    await expect(storage.stage(storage.newKey(), Readable.from([]), 10)).rejects.toMatchObject({ status: 400 });
    await expect(storage.stage(storage.newKey(), Readable.from([Buffer.from('abc')]), 2)).rejects.toMatchObject({ status: 413 });
  });
  it('cleans a partial file after an interrupted stream', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'maturity-')); roots.push(root);
    const storage = new FileStorage(root); const key = storage.newKey();
    async function* interrupted() { yield Buffer.from('partial'); throw new Error('stream interrupted'); }
    await expect(storage.stage(key, interrupted(), 100)).rejects.toThrow('stream interrupted');
    await expect(readFile(path.join(root, 'staging', key))).rejects.toMatchObject({ code: 'ENOENT' });
  });
});
