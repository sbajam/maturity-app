import { describe, expect, it, vi } from 'vitest';
import { Readable } from 'node:stream';

const mocks = vi.hoisted(() => ({ write: vi.fn(), close: vi.fn(), unlink: vi.fn() }));
vi.mock('node:fs/promises', async importOriginal => {
  const original = await importOriginal<typeof import('node:fs/promises')>();
  return { ...original, mkdir: vi.fn().mockResolvedValue(undefined), open: vi.fn().mockResolvedValue({ write: mocks.write, close: mocks.close }), unlink: mocks.unlink };
});
import { FileStorage } from '../../src/utils/file-storage.js';

describe('write failure', () => {
  it('closes and removes the partial staged file when writing fails', async () => {
    mocks.write.mockRejectedValue(new Error('disk full')); mocks.close.mockResolvedValue(undefined); mocks.unlink.mockResolvedValue(undefined);
    const storage = new FileStorage('test-root');
    await expect(storage.stage(storage.newKey(), Readable.from([Buffer.from('data')]), 100)).rejects.toThrow('disk full');
    expect(mocks.close).toHaveBeenCalledOnce(); expect(mocks.unlink).toHaveBeenCalledOnce();
  });
});
