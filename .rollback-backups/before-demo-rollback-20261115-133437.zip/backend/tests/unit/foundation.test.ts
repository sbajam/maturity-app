import { describe, expect, it } from 'vitest';
import { parseEnv } from '../../src/config/env.js';
import { idSchema, paginationSchema } from '../../src/schemas/common.schema.js';
import { pagination } from '../../src/utils/pagination.js';

const env = parseEnv({ DATABASE_URL: 'postgres://user:password@localhost/test', CORS_ORIGIN: 'http://localhost:3000', UPLOAD_ROOT: './test-uploads', NODE_ENV: 'test' });

describe('foundation', () => {
  it('validates identifiers and pagination', () => {
    expect(idSchema.safeParse('-1').success).toBe(false);
    expect(idSchema.safeParse('1x').success).toBe(false);
    expect(paginationSchema.parse({})).toEqual({ page: 1, pageSize: 20 });
    expect(paginationSchema.safeParse({ pageSize: '101' }).success).toBe(false);
    expect(pagination(3, 20)).toEqual({ limit: 20, offset: 40 });
  });
  it('rejects public hosts and incomplete settings', () => {
    expect(() => parseEnv({ ...env, HOST: '0.0.0.0', PORT: String(env.PORT), MAX_UPLOAD_BYTES: String(env.MAX_UPLOAD_BYTES) })).toThrow();
    expect(() => parseEnv({})).toThrow();
  });
});
