import { beforeEach, describe, expect, it, vi } from 'vitest';
import request from 'supertest';
import { AppError } from '../../src/contracts/errors.js';

const mocks = vi.hoisted(() => ({ listEnterprises: vi.fn(), createEnterprise: vi.fn(), getEnterprise: vi.fn(), removeEnterprise: vi.fn() }));
vi.mock('../../src/services/enterprise.service.js', () => mocks);
import { createApp } from '../../src/app.js';
import { parseEnv } from '../../src/config/env.js';

const app = createApp(parseEnv({ DATABASE_URL: 'postgres://placeholder:placeholder@localhost/test', CORS_ORIGIN: 'http://localhost:3000', UPLOAD_ROOT: './unused', NODE_ENV: 'test' }));
describe('HTTP response contracts', () => {
  beforeEach(() => vi.resetAllMocks());
  it('returns stable pagination in the list envelope', async () => {
    mocks.listEnterprises.mockResolvedValue({ data: [], pagination: { page: 2, pageSize: 5, total: 6 } });
    const response = await request(app).get('/api/v1/enterprises?page=2&pageSize=5');
    expect(response.status).toBe(200); expect(response.body).toEqual({ data: [], pagination: { page: 2, pageSize: 5, total: 6 } });
    expect(mocks.listEnterprises).toHaveBeenCalledWith(2, 5);
  });
  it('rejects invalid identifiers and unknown fields', async () => {
    expect((await request(app).get('/api/v1/enterprises/-1')).body.error.code).toBe('VALIDATION_ERROR');
    expect((await request(app).post('/api/v1/enterprises').send({ name: 'X', industry: 'Y', extra: true })).status).toBe(400);
  });
  it('returns 404, 409 and bodyless 204', async () => {
    mocks.getEnterprise.mockRejectedValue(new AppError(404, 'NOT_FOUND', 'Resource not found'));
    expect((await request(app).get('/api/v1/enterprises/1')).status).toBe(404);
    mocks.removeEnterprise.mockRejectedValueOnce(new AppError(409, 'RESOURCE_NOT_EMPTY', 'Resource has dependent records')).mockResolvedValueOnce(undefined);
    expect((await request(app).delete('/api/v1/enterprises/1')).body.error.code).toBe('RESOURCE_NOT_EMPTY');
    const response = await request(app).delete('/api/v1/enterprises/1'); expect(response.status).toBe(204); expect(response.text).toBe('');
  });
  it('does not expose internal exception messages', async () => {
    mocks.getEnterprise.mockRejectedValue(new Error('sensitive internal value'));
    const response = await request(app).get('/api/v1/enterprises/1');
    expect(response.status).toBe(500); expect(JSON.stringify(response.body)).not.toContain('sensitive');
  });
});
