import { describe, expect, it } from 'vitest';
import { Sequelize } from 'sequelize';
import { Assessment, DataSource, Enterprise, initModels, SourceDocument } from '../../src/models/index.js';

describe('model metadata', () => {
  const sequelize = new Sequelize('postgres://user:password@localhost/test', { logging: false });
  initModels(sequelize);

  it('maps the four tables and foreign keys to database columns', () => {
    expect(Enterprise.tableName).toBe('enterprises');
    expect(DataSource.tableName).toBe('data_sources');
    expect(SourceDocument.tableName).toBe('source_documents');
    expect(Assessment.tableName).toBe('assessments');
    expect(DataSource.rawAttributes.enterpriseId.field).toBe('enterprise_id');
    expect(SourceDocument.rawAttributes.dataSourceId.field).toBe('data_source_id');
    expect(Assessment.rawAttributes.enterpriseId.field).toBe('enterprise_id');
  });

  it('defines ownership associations and draft defaults', () => {
    expect(Enterprise.associations.dataSources.target).toBe(DataSource);
    expect(Enterprise.associations.assessments.target).toBe(Assessment);
    expect(DataSource.associations.documents.target).toBe(SourceDocument);
    expect(Assessment.rawAttributes.status.defaultValue).toBe('draft');
    expect(Assessment.rawAttributes.version.defaultValue).toBe('1.0');
  });
});
