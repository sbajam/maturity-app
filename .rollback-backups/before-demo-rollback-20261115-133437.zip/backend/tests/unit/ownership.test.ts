import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  transaction: vi.fn(),
  findEnterprise: vi.fn(),
  findSource: vi.fn(),
  countSource: vi.fn(),
  countAssessment: vi.fn(),
  countDocument: vi.fn(),
  destroy: vi.fn(),
}));
vi.mock('../../src/models/index.js', () => {
  const sequelize = { transaction: mocks.transaction };
  return {
    Enterprise: { sequelize, findByPk: mocks.findEnterprise },
    DataSource: { sequelize, findOne: mocks.findSource, count: mocks.countSource },
    Assessment: { count: mocks.countAssessment },
    SourceDocument: { count: mocks.countDocument },
  };
});
import { removeEnterprise } from '../../src/services/enterprise.service.js';
import { removeDataSource, updateDataSource } from '../../src/services/data-source.service.js';

describe('ownership and dependent resources', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.transaction.mockImplementation(async callback => callback({ LOCK: { UPDATE: 'UPDATE' } }));
  });
  it('returns conflict without deleting an enterprise with a dependent source', async () => {
    mocks.findEnterprise.mockResolvedValue({ destroy: mocks.destroy });
    mocks.countSource.mockResolvedValue(1);
    mocks.countAssessment.mockResolvedValue(0);
    await expect(removeEnterprise(1)).rejects.toMatchObject({ status: 409, code: 'RESOURCE_NOT_EMPTY' });
    expect(mocks.destroy).not.toHaveBeenCalled();
  });
  it('returns not found when the source does not belong to the enterprise', async () => {
    mocks.findSource.mockResolvedValue(null);
    await expect(updateDataSource(1, 9, { enabled: true })).rejects.toMatchObject({ status: 404 });
    expect(mocks.findSource).toHaveBeenCalledWith(expect.objectContaining({ where: { id: 9, enterpriseId: 1 } }));
  });
  it('prevents deleting a source with documents', async () => {
    mocks.findSource.mockResolvedValue({ destroy: mocks.destroy });
    mocks.countDocument.mockResolvedValue(1);
    await expect(removeDataSource(1, 2)).rejects.toMatchObject({ status: 409, code: 'RESOURCE_NOT_EMPTY' });
    expect(mocks.destroy).not.toHaveBeenCalled();
  });
});
