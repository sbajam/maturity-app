import { mkdtemp, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { Readable } from 'node:stream';
import { describe, expect, it } from 'vitest';
import { FileStorage } from '../../src/utils/file-storage.js';
import { reconcileFiles } from '../../src/utils/reconcile-files.js';

describe('file reconciliation', () => {
  it('restores committed files, removes orphans and preserves ambiguous copies repeatedly', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'maturity-reconcile-'));
    try {
      const storage = new FileStorage(root); const live = storage.newKey(); const orphan = storage.newKey(); const ambiguous = storage.newKey();
      for (const key of [live, orphan, ambiguous]) await storage.stage(key, Readable.from([Buffer.from('x')]), 10);
      await storage.move(live, 'staging', 'quarantine'); await storage.move(orphan, 'staging', 'objects');
      await writeFile(path.join(root, 'objects', ambiguous), 'x');
      const keys = new Set([live, ambiguous]);
      await reconcileFiles(root, keys, 0); await reconcileFiles(root, keys, 0);
      expect(await readdir(path.join(root, 'objects'))).toEqual(expect.arrayContaining([live, ambiguous]));
      expect(await readdir(path.join(root, 'objects'))).not.toContain(orphan);
      expect(await readdir(path.join(root, 'staging'))).toContain(ambiguous);
    } finally { await rm(root, { recursive: true, force: true }); }
  });
});
