import { Readable } from 'node:stream';
import { describe, expect, it, vi } from 'vitest';
import request from 'supertest';

const list = vi.hoisted(() => ({ data: [], pagination: { page: 1, pageSize: 20, total: 0 } }));
vi.mock('../../src/services/enterprise.service.js', () => ({ listEnterprises: vi.fn().mockResolvedValue(list), createEnterprise: vi.fn().mockResolvedValue({ id: 1 }), getEnterprise: vi.fn().mockResolvedValue({ id: 1 }), removeEnterprise: vi.fn() }));
vi.mock('../../src/services/data-source.service.js', () => ({ listDataSources: vi.fn().mockResolvedValue(list), createDataSource: vi.fn().mockResolvedValue({ id: 2 }), updateDataSource: vi.fn().mockResolvedValue({ id: 2 }), removeDataSource: vi.fn() }));
vi.mock('../../src/services/assessment.service.js', () => ({ listAssessments: vi.fn().mockResolvedValue(list), createAssessment: vi.fn().mockResolvedValue({ id: 3, status: 'draft' }), getAssessment: vi.fn().mockResolvedValue({ id: 3 }), removeAssessment: vi.fn() }));
vi.mock('../../src/services/dashboard.service.js', () => ({ dashboardSummary: vi.fn().mockResolvedValue({ enterpriseCount: 0, enabledSourceCount: 0, draftAssessmentCount: 0, latestResult: null }) }));
vi.mock('../../src/services/document.service.js', () => ({ listDocuments: vi.fn().mockResolvedValue(list), uploadDocument: vi.fn().mockResolvedValue({ id: 4 }), downloadDocument: vi.fn().mockResolvedValue({ document: { originalName: 'test.txt', mediaType: 'text/plain' }, file: { createReadStream: () => Readable.from(['test']) } }), removeDocument: vi.fn() }));
import { createApp } from '../../src/app.js';
import { parseEnv } from '../../src/config/env.js';

const app = createApp(parseEnv({ DATABASE_URL: 'postgres://placeholder:placeholder@localhost/test', CORS_ORIGIN: 'http://localhost:3000', UPLOAD_ROOT: './unused', NODE_ENV: 'test' }));
describe('route wiring', () => {
  it('mounts all 17 operations and invokes mocked services', async () => {
    const e = '/api/v1/enterprises'; const s = `${e}/1/data-sources`; const a = `${e}/1/assessments`; const d = `${s}/2/documents`;
    expect((await request(app).get(e)).status).toBe(200);
    expect((await request(app).post(e).send({ name: 'A', industry: 'B' })).status).toBe(201);
    expect((await request(app).get(`${e}/1`)).status).toBe(200);
    expect((await request(app).delete(`${e}/1`)).status).toBe(204);
    expect((await request(app).get(s)).status).toBe(200);
    expect((await request(app).post(s).send({ name: 'A', type: 'custom' })).status).toBe(201);
    expect((await request(app).patch(`${s}/2`).send({ enabled: false })).status).toBe(200);
    expect((await request(app).delete(`${s}/2`)).status).toBe(204);
    expect((await request(app).get(a)).status).toBe(200);
    expect((await request(app).post(a).send({ name: 'Draft' })).status).toBe(201);
    expect((await request(app).get(`${a}/3`)).status).toBe(200);
    expect((await request(app).delete(`${a}/3`)).status).toBe(204);
    expect((await request(app).get('/api/v1/dashboard')).status).toBe(200);
    expect((await request(app).get(d)).status).toBe(200);
    expect((await request(app).post(d).attach('file', Buffer.from('text'), 'test.txt')).status).toBe(201);
    const download = await request(app).get(`${d}/4/content`);
    expect(download.status).toBe(200); expect(download.headers['x-content-type-options']).toBe('nosniff');
    expect((await request(app).delete(`${d}/4`)).status).toBe(204);
  });
});
