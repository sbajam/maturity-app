<script setup lang="ts">
import { demoService, type DemoWizardState } from '~/services/demo'
import { aggregateDemoTree, type DemoResult } from '~/utils/demo-model'
import { downloadDemoContext } from '~/utils/demo-export'

const props = defineProps<{ enterpriseId: number; assessmentId: number; report?: boolean }>()
const config = useRuntimeConfig()
const base = import.meta.server ? config.demoApiBase : config.public.demoApiBase
const demo = demoService(base)
const api = useApi()
const message = ref('')
const saving = ref(false)
const { data, pending, error, refresh } = await useAsyncData(`demo-flow-${props.enterpriseId}-${props.assessmentId}`, async () => {
  const [enterprise, assessment, sources, capabilities, state] = await Promise.all([
    api.getEnterprise(props.enterpriseId), api.getAssessment(props.enterpriseId, props.assessmentId),
    api.listSources(props.enterpriseId, 1, 100), demo.capabilities(), demo.state(props.enterpriseId, props.assessmentId),
  ])
  return { enterprise: enterprise.data, assessment: assessment.data, sources: sources.data, capabilities, state }
})
const state = ref<DemoWizardState>({ step: 1, sourceIds: [], leafIds: [], scope: '', notes: '' })
watch(data, value => { if (value) state.value = value.state ?? { step: 1, sourceIds: [], leafIds: [], scope: '', notes: '' } }, { immediate: true })
const roots = computed(() => data.value?.capabilities.filter(node => node.parentId === null) ?? [])
const results = computed(() => {
  const nodes = data.value?.capabilities ?? []
  const parents = new Set(nodes.map(node => node.parentId))
  const leaves: Record<string, DemoResult> = {}
  for (const node of nodes.filter(item => !parents.has(item.id))) {
    const index = state.value.leafIds.indexOf(node.id)
    leaves[node.id] = index < 0 ? { score: null, status: 'not_selected' } : index % 2 === 0 && state.value.sourceIds.length ? { score: 4, status: 'sufficient' } : { score: null, status: 'insufficient' }
  }
  return aggregateDemoTree(nodes, leaves)
})
const selectedNodes = computed(() => (data.value?.capabilities ?? []).filter(node => state.value.leafIds.includes(node.id)))
function toggle(ids: string[], checked: boolean) {
  state.value.leafIds = checked ? [...new Set([...state.value.leafIds, ...ids])] : state.value.leafIds.filter(id => !ids.includes(id))
}
async function move(step: number) {
  if (step > 1 && (!state.value.sourceIds.length || !state.value.leafIds.length)) { message.value = 'Select at least one source and one leaf capability.'; return }
  const next = { ...state.value, step }
  saving.value = true; message.value = ''
  try { state.value = await demo.save(props.enterpriseId, props.assessmentId, next) }
  catch { message.value = 'Unable to save Demo progress. Your selections are still on this page.' }
  finally { saving.value = false }
}
async function downloadFixture(type: 'capability_excel' | 'business_document') {
  message.value = ''
  try { await demo.downloadFixture(type === 'capability_excel' ? 'vendow-workbook' : 'vendow-document') }
  catch { message.value = 'Unable to download the Demo fixture.' }
}
function download() {
  if (!data.value) return
  const enterprise = { id: String(props.enterpriseId), name: data.value.enterprise.name, industry: data.value.enterprise.industry }
  const assessment = { id: String(props.assessmentId), enterpriseId: enterprise.id, name: data.value.assessment.name, ...state.value, sourceIds: state.value.sourceIds.map(String) }
  const sources = data.value.sources.map(source => ({ id: String(source.id), enterpriseId: enterprise.id, name: source.name, type: source.type, method: 'unconfigured' as const, enabled: source.enabled, files: [] }))
  downloadDemoContext(enterprise, assessment, sources, data.value.capabilities)
}
function printReport() { window.print() }
</script>

<template>
  <div v-if="pending" class="p-8">Loading Demo assessment...</div>
  <div v-else-if="error || !data" role="alert" class="p-8 text-red-700">Unable to load the Demo assessment. <button class="underline" @click="refresh()">Retry</button></div>
  <div v-else class="space-y-5">
    <p class="rounded-lg bg-amber-100 p-3 font-semibold text-amber-900">Demo / Simulated Results — no real AI analysis</p>
    <NuxtLink :to="`/enterprise/${enterpriseId}/assessments/${assessmentId}`" class="text-blue-700 underline">Back to assessment</NuxtLink>
    <h1 class="text-2xl font-bold">{{ report ? 'Assessment Report' : 'Assessment Wizard' }} · {{ data.assessment.name }}</h1>
    <p class="text-sm text-slate-600">{{ data.enterprise.name }} · Step {{ state.step }} of 5</p>
    <p v-if="message" role="alert" class="text-red-700">{{ message }}</p>
    <template v-if="!report && state.step === 1">
      <AppCard title="Data Sources"><div v-for="source in data.sources" :key="source.id" class="py-2"><label><input v-model="state.sourceIds" type="checkbox" :value="source.id"> {{ source.name }} · {{ source.type }} · {{ source.enabled ? 'Enabled' : 'Disabled' }} <span v-if="source.type === 'clarity' || source.type === 'matomo'">· Not Connected</span></label><button v-if="source.type === 'capability_excel' || source.type === 'business_document'" class="ms-2 text-sm text-blue-700 underline" @click="downloadFixture(source.type)">Download Vendow sample</button></div></AppCard>
      <AppCard title="Capability Framework" description="Vendow fixture derived from the workbook; not a live import."><div class="max-h-96 overflow-auto"><DemoCapabilityNode v-for="node in roots" :key="node.id" :node="node" :nodes="data.capabilities" :selected="state.leafIds" mode="select" @toggle="toggle" /></div></AppCard>
    </template>
    <AppCard v-else-if="!report && state.step === 2" title="Assessment Configuration"><label class="block">Scope <input v-model="state.scope" class="block w-full rounded border p-2"></label><label class="mt-3 block">Notes <textarea v-model="state.notes" class="block w-full rounded border p-2" /></label><p class="mt-3 text-sm">{{ state.sourceIds.length }} sources · {{ state.leafIds.length }} capabilities selected</p><button class="mt-3 text-blue-700 underline" @click="download">Download Assessment Context</button></AppCard>
    <AppCard v-else-if="!report && state.step === 3" title="Evidence & Mapping · Simulated"><p class="text-sm">Examples are simulated and are not extracted facts.</p><ul class="mt-3 space-y-2"><li v-for="(node, index) in selectedNodes" :key="node.id">{{ node.name }} — Demo evidence {{ index + 1 }} · {{ results[node.id]?.score == null ? 'Insufficient' : 'Sufficient' }}</li></ul></AppCard>
    <AppCard v-else-if="!report && state.step === 4" title="AI Analysis · Simulated"><p>No LLM was run. Scores are illustrative and follow the Demo evidence status.</p><p v-for="node in selectedNodes" :key="node.id" class="mt-2">{{ node.name }} — {{ results[node.id]?.score == null ? 'Insufficient evidence; no score' : 'Sample score 4 / 5' }}</p></AppCard>
    <AppCard v-else title="Results · Simulated"><p class="mb-3">A parent is incomplete if any direct child has no score. Missing evidence is not zero.</p><DemoCapabilityNode v-for="node in roots" :key="node.id" :node="node" :nodes="data.capabilities" :selected="state.leafIds" :results="results" mode="report" /><NuxtLink v-if="!report" :to="`/enterprise/${enterpriseId}/assessments/${assessmentId}/report`" class="mt-4 inline-block text-blue-700 underline">Open report</NuxtLink><button v-else class="mt-4 block text-blue-700 underline" @click="printReport">Print</button></AppCard>
    <div v-if="!report" class="flex gap-3"><UiButton v-if="state.step > 1" variant="outline" :disabled="saving" @click="move(state.step - 1)">Back</UiButton><UiButton v-if="state.step < 5" :disabled="saving" @click="move(state.step + 1)">Next</UiButton></div>
  </div>
</template>
