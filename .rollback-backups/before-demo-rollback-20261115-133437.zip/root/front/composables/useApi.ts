import { createApi } from '~/services/api'
import { demoService } from '~/services/demo'

export function useApi() {
  const config = useRuntimeConfig()
  const demo = config.public.demoMode
  const base = demo ? (import.meta.server ? config.demoApiBase : config.public.demoApiBase) : (import.meta.server ? config.apiBase : config.public.apiBase)
  const api = createApi(base)
  if (!demo) return api
  return new Proxy(api, {
    get(target, property: keyof typeof api) {
      return async (...args: never[]) => {
        await demoService(base).capabilities()
        const method = target[property] as (...input: never[]) => Promise<unknown>
        return method(...args)
      }
    },
  })
}
