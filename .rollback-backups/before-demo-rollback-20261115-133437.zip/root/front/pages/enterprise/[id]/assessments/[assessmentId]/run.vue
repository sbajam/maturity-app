﻿<script setup lang="ts">
import { validRouteId } from '~/services/api'
const route = useRoute()
const demoMode = useRuntimeConfig().public.demoMode
if (!demoMode || !validRouteId(route.params.id) || !validRouteId(route.params.assessmentId)) {
  await navigateTo(`/enterprise/${route.params.id}/assessments/${route.params.assessmentId}`, { replace: true })
}
</script>

<template>
  <DemoAssessmentFlow v-if="demoMode && validRouteId(route.params.id) && validRouteId(route.params.assessmentId)" :enterprise-id="Number(route.params.id)" :assessment-id="Number(route.params.assessmentId)" />
</template>
