import { $fetch } from 'ofetch'
import type { DemoCapability } from '~/utils/demo-model'

export interface DemoWizardState {
  step: number
  sourceIds: number[]
  leafIds: string[]
  scope: string
  notes: string
}

export function demoService(baseURL: string) {
  const route = (enterpriseId: number, assessmentId: number) => `/demo/enterprises/${enterpriseId}/assessments/${assessmentId}/state`
  return {
    capabilities: async () => (await $fetch<{ data: DemoCapability[] }>('/demo/capabilities', { baseURL })).data,
    state: async (enterpriseId: number, assessmentId: number) => (await $fetch<{ data: DemoWizardState | null }>(route(enterpriseId, assessmentId), { baseURL })).data,
    save: async (enterpriseId: number, assessmentId: number, state: DemoWizardState) => (await $fetch<{ data: DemoWizardState }>(route(enterpriseId, assessmentId), { baseURL, method: 'PUT', body: state })).data,
    downloadFixture: async (name: 'vendow-workbook' | 'vendow-document') => {
      const blob = await $fetch<Blob>(`/demo/fixtures/${name}/content`, { baseURL, responseType: 'blob' })
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a'); link.href = url; link.download = name === 'vendow-workbook' ? 'vendow-capabilities.xlsx' : 'vendow-document.pdf'; link.click(); URL.revokeObjectURL(url)
    },
  }
}
